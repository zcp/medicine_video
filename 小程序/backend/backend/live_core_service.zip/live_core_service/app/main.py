from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.core.config import Settings
from app.api.v1.api import api_router

import logging
import os
from logging.handlers import RotatingFileHandler
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 初始化设置
settings = Settings()
# ------- 配置日志系统（放在最前面）-------
#setup_logging( level=logging.INFO)
# --- 1. 导入未配置的 celery_app 实例 ---
from app.tasks.celery_app import app as celery_app

# --- 2. 在这里对导入的实例进行生产环境配置 ---
celery_app.config_from_object(settings, namespace="CELERY")
celery_app.autodiscover_tasks(packages=["app.tasks"])



# 创建FastAPI应用实例
app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="直播核心服务 - 管理直播房间和会话",
    # 禁用自动重定向，避免307问题
    redirect_slashes=False
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 在生产环境中应该限制为特定域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 配置媒体文件静态访问
MEDIA_ROOT_PATH = os.getenv("MEDIA_ROOT_PATH", "./media")

# 确保media目录存在
os.makedirs(MEDIA_ROOT_PATH, exist_ok=True)

# 挂载静态文件目录
app.mount("/media", StaticFiles(directory=MEDIA_ROOT_PATH), name="media")

# 注册API路由
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/")
async def root():
    """根路径"""
    return {"message": "LiveCore Service is running", "version": settings.VERSION} 