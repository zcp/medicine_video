"""
LiveCore Service - File Handler

This module contains the FileHandler utility class for handling file upload,
validation, storage, and management operations.
"""

import os
import uuid
import time
import logging
from pathlib import Path
from typing import Optional, Tuple
from fastapi import UploadFile, HTTPException

# 设置日志
logger = logging.getLogger(__name__)

# 从环境变量读取配置
MEDIA_ROOT_PATH = os.getenv("MEDIA_ROOT_PATH", "./media")
UPLOAD_MAX_SIZE = int(os.getenv("UPLOAD_MAX_SIZE", "5242880"))
UPLOAD_ALLOWED_EXTENSIONS = os.getenv("UPLOAD_ALLOWED_EXTENSIONS", "jpg,jpeg,png,gif").split(",")

# 允许的MIME类型
ALLOWED_MIME_TYPES = ["image/jpeg", "image/png", "image/gif"]


class FileHandler:
    """文件处理工具类"""
    
    @staticmethod
    def validate_image_file(file: UploadFile) -> bool:
        """
        验证文件类型和大小
        
        Args:
            file: 上传的文件对象
            
        Returns:
            验证通过返回True
            
        Raises:
            HTTPException: 验证失败时抛出异常
        """
        logger.debug(f"开始验证文件: filename={file.filename}, content_type={file.content_type}")
        
        # 检查文件扩展名
        if file.filename:
            file_ext = file.filename.rsplit(".", 1)[-1].lower()
            if file_ext not in UPLOAD_ALLOWED_EXTENSIONS:
                logger.warning(f"文件类型不允许: extension={file_ext}")
                raise HTTPException(
                    status_code=400,
                    detail=f"不支持的文件类型。仅允许：{', '.join(UPLOAD_ALLOWED_EXTENSIONS)}"
                )
        
        # 检查MIME类型
        if file.content_type not in ALLOWED_MIME_TYPES:
            logger.warning(f"MIME类型不允许: content_type={file.content_type}")
            raise HTTPException(
                status_code=400,
                detail=f"不支持的MIME类型。仅允许：{', '.join(ALLOWED_MIME_TYPES)}"
            )
        
        # 检查文件大小
        # 注意：由于file.size可能不可用，我们在读取时检查大小
        logger.debug(f"文件验证通过: filename={file.filename}")
        return True
    
    @staticmethod
    def generate_cover_path(room_id: uuid.UUID, extension: str) -> Tuple[str, str]:
        """
        生成封面存储路径
        
        Args:
            room_id: 房间ID
            extension: 文件扩展名
            
        Returns:
            (文件系统路径, URL路径)的元组
        """
        # 生成时间戳
        timestamp = int(time.time())
        
        # 构建路径
        relative_dir = f"rooms/{room_id}"
        filename = f"cover_{timestamp}.{extension}"
        
        # 文件系统路径
        fs_dir = os.path.join(MEDIA_ROOT_PATH, relative_dir)
        fs_path = os.path.join(fs_dir, filename)
        
        # URL路径
        url_path = f"/media/{relative_dir}/{filename}"
        
        # 确保目录存在
        os.makedirs(fs_dir, exist_ok=True)
        logger.debug(f"生成封面路径: fs_path={fs_path}, url_path={url_path}")
        
        return fs_path, url_path
    
    @staticmethod
    async def save_cover_file(file: UploadFile, room_id: uuid.UUID) -> str:
        """
        保存封面文件并返回URL
        
        Args:
            file: 上传的文件对象
            room_id: 房间ID
            
        Returns:
            文件的URL路径
            
        Raises:
            HTTPException: 保存失败时抛出异常
        """
        logger.info(f"开始保存封面文件: room_id={room_id}, filename={file.filename}")
        
        try:
            # 1. 验证文件
            FileHandler.validate_image_file(file)
            
            # 2. 获取文件扩展名
            file_ext = file.filename.rsplit(".", 1)[-1].lower() if file.filename else "jpg"
            
            # 3. 生成存储路径
            fs_path, url_path = FileHandler.generate_cover_path(room_id, file_ext)
            
            # 4. 读取文件内容并检查大小
            contents = await file.read()
            if len(contents) > UPLOAD_MAX_SIZE:
                logger.warning(f"文件大小超出限制: size={len(contents)}, max={UPLOAD_MAX_SIZE}")
                raise HTTPException(
                    status_code=400,
                    detail=f"文件大小超出限制。最大允许：{UPLOAD_MAX_SIZE / 1024 / 1024:.1f}MB"
                )
            
            # 5. 保存文件
            with open(fs_path, "wb") as f:
                f.write(contents)
            
            logger.info(f"封面文件保存成功: room_id={room_id}, path={url_path}")
            return url_path
            
        except HTTPException:
            # 重新抛出HTTP异常
            raise
        except Exception as e:
            logger.error(f"保存封面文件失败: room_id={room_id}, error={str(e)}", exc_info=True)
            raise HTTPException(
                status_code=500,
                detail="文件保存失败"
            )
    
    @staticmethod
    def delete_old_cover(cover_url: str) -> None:
        """
        删除旧的封面文件
        
        Args:
            cover_url: 封面URL路径
        """
        if not cover_url:
            return
        
        try:
            # 从URL路径转换为文件系统路径
            # URL格式: /media/rooms/{room_id}/cover_{timestamp}.{ext}
            # 移除开头的 /media/
            relative_path = cover_url.replace("/media/", "")
            fs_path = os.path.join(MEDIA_ROOT_PATH, relative_path)
            
            # 检查文件是否存在
            if os.path.exists(fs_path):
                os.remove(fs_path)
                logger.info(f"成功删除旧封面文件: path={fs_path}")
            else:
                logger.debug(f"旧封面文件不存在: path={fs_path}")
                
        except Exception as e:
            # 删除失败时只记录警告，不中断流程
            logger.warning(f"删除旧封面文件失败: cover_url={cover_url}, error={str(e)}")

