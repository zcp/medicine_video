"""
LiveCore Service - Room Service Unit Tests

This module contains comprehensive unit tests for the RoomService class,
testing all business logic in complete isolation using mocks.
"""

import pytest
import uuid
from datetime import datetime
from unittest.mock import AsyncMock
from typing import List, Dict, Any

from app.services.room_service import RoomService
from app.schemas.live_core import LiveRoomCreate, LiveRoomUpdate
from app.models.live_core import LiveRoom
from app.exceptions import (
    RoomNotFoundException,
    ActionForbiddenException,
    ParentRoomNotFoundException
)


# ==================== Test Data Fixtures ====================

def create_mock_room(
    room_id: uuid.UUID = None,
    title: str = "测试房间",
    description: str = "测试描述",
    stream_key: str = "sk_live_test123",
    is_private: bool = False,
    record_by_default: bool = True,
    parent_room_id: uuid.UUID = None,
    user_id: uuid.UUID = None
) -> LiveRoom:
    """创建模拟的LiveRoom对象"""
    if room_id is None:
        room_id = uuid.uuid4()
    
    mock_room = LiveRoom()
    mock_room.id = room_id
    mock_room.title = title
    mock_room.description = description
    mock_room.stream_key = stream_key
    mock_room.is_private = is_private
    mock_room.record_by_default = record_by_default
    mock_room.parent_room_id = parent_room_id
    mock_room.user_id = user_id
    mock_room.created_at = datetime.utcnow()
    mock_room.updated_at = datetime.utcnow()
    
    return mock_room


def create_room_create_data(
    title: str = "新建房间",
    description: str = "新建房间描述",
    parent_room_id: uuid.UUID = None,
    user_id: uuid.UUID = None
) -> LiveRoomCreate:
    """创建房间创建请求数据"""
    return LiveRoomCreate(
        title=title,
        description=description,
        parent_room_id=parent_room_id,
        user_id=user_id,
        is_private=False,
        record_by_default=True
    )


def create_room_update_data(
    title: str = "更新后的房间",
    description: str = "更新后的描述"
) -> LiveRoomUpdate:
    """创建房间更新请求数据"""
    return LiveRoomUpdate(
        title=title,
        description=description
    )


# ==================== create_new_room Tests ====================

@pytest.fixture
def mock_test_user():
    """为单元测试提供模拟用户数据"""
    return {
        "public_id": "550e8400-e29b-41d4-a716-446655440000",
        "username": "test_user",
        "email": "test@example.com"
    }

@pytest.mark.asyncio
async def test_create_new_room_success(mocker, mock_test_user):
    """
    测试成功创建新房间
    - 模拟CRUD层创建操作
    - 验证返回正确的房间对象
    """
    # Arrange
    mock_room = create_mock_room(user_id=mock_test_user['public_id'])
    room_create_data = create_room_create_data(user_id=mock_test_user['public_id'])

    # Mock CRUD operations
    mock_create = mocker.patch("app.crud.room.create", return_value=mock_room)
    mock_create.return_value = mock_room

    # Act
    service = RoomService(db=None)  # db不会被使用，因为都被mock了
    result = await service.create_new_room(room_create_data,user_id=mock_test_user['public_id'])

    # Assert
    assert result == mock_room
    mock_create.assert_called_once_with(db=None, obj_in=room_create_data, user_id=mock_test_user['public_id'])


@pytest.mark.asyncio
async def test_create_new_room_with_parent_success(mocker, mock_test_user):
    """
    测试成功创建分会场（带父房间ID）
    - 模拟父房间存在的情况
    - 验证创建成功
    """
    # Arrange
    parent_room_id = uuid.uuid4()
    mock_parent_room = create_mock_room(room_id=parent_room_id, title="主会场", user_id=mock_test_user['public_id'])
    mock_room = create_mock_room(parent_room_id=parent_room_id, title="分会场", user_id=mock_test_user['public_id'])
    room_create_data = create_room_create_data(
        title="分会场",
        parent_room_id=parent_room_id,
        user_id=mock_test_user['public_id']
    )

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_parent_room)
    mock_create = mocker.patch("app.crud.room.create", return_value=mock_room)

    # Act
    service = RoomService(db=None)
    result = await service.create_new_room(room_create_data, user_id=mock_test_user['public_id'])

    # Assert
    assert result == mock_room
    mock_get.assert_called_once_with(db=None, room_id=parent_room_id)
    mock_create.assert_called_once_with(db=None, obj_in=room_create_data, user_id=mock_test_user['public_id'])

@pytest.mark.asyncio
async def test_create_sub_venue_parent_not_found(mocker, mock_test_user):
    """
    测试创建分会场时父房间不存在的情况
    - 模拟父房间不存在
    - 验证抛出ParentRoomNotFoundException异常
    """
    # Arrange
    parent_room_id = uuid.uuid4()
    room_create_data = create_room_create_data(
        title="分会场",
        parent_room_id=parent_room_id,
        user_id=mock_test_user['public_id']
    )

    # Mock CRUD operations - 父房间不存在
    mock_get = mocker.patch("app.crud.room.get", return_value=None)

    # Act & Assert
    service = RoomService(db=None)
    with pytest.raises(ParentRoomNotFoundException):
        await service.create_new_room(room_create_data, user_id=mock_test_user['public_id'])

    mock_get.assert_called_once_with(db=None, room_id=parent_room_id)


# ==================== get_room_list Tests ====================

@pytest.mark.asyncio
async def test_get_room_list_success(mocker, mock_test_user):
    """
    测试成功获取房间列表
    - 模拟CRUD层返回房间列表和总数
    - 验证返回正确的数据和分页计算
    """
    # Arrange
    mock_room_1 = create_mock_room(title="房间1", user_id=mock_test_user['public_id'])
    mock_room_2 = create_mock_room(title="房间2", user_id=mock_test_user['public_id'])
    mock_rooms = [mock_room_1, mock_room_2]
    mock_total = 10

    # Mock CRUD operations
    mock_get_multi = mocker.patch(
        "app.crud.room.get_multi_and_total",
        return_value=(mock_rooms, mock_total)
    )

    # Act
    service = RoomService(db=None)
    result_rooms, result_total = await service.get_room_list(page=2, size=5, user_id=mock_test_user['public_id'])

    # Assert
    assert result_rooms == mock_rooms
    assert result_total == mock_total
    # 验证skip计算: (page - 1) * size = (2 - 1) * 5 = 5
    mock_get_multi.assert_called_once_with(db=None, skip=5, limit=5, user_id=mock_test_user['public_id'])


@pytest.mark.asyncio
async def test_get_room_list_empty_result(mocker, mock_test_user):
    """
    测试获取空房间列表
    - 模拟没有房间的情况
    - 验证返回空列表和0总数
    """
    # Arrange
    mock_rooms = []
    mock_total = 0

    # Mock CRUD operations
    mock_get_multi = mocker.patch(
        "app.crud.room.get_multi_and_total",
        return_value=(mock_rooms, mock_total)
    )

    # Act
    service = RoomService(db=None)
    result_rooms, result_total = await service.get_room_list(page=1, size=10, user_id=mock_test_user['public_id'])

    # Assert
    assert result_rooms == []
    assert result_total == 0
    mock_get_multi.assert_called_once_with(db=None, skip=0, limit=10, user_id=mock_test_user['public_id'])


# ==================== get_room_details Tests ====================

@pytest.mark.asyncio
async def test_get_room_details_success(mocker, mock_test_user):
    """
    测试成功获取房间详情
    - 模拟房间存在的情况
    - 验证返回正确的房间对象
    """
    # Arrange
    room_id = uuid.uuid4()
    mock_room = create_mock_room(room_id=room_id, user_id=mock_test_user['public_id'])

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_room)

    # Act
    service = RoomService(db=None)
    result = await service.get_room_details(room_id, user_id=mock_test_user['public_id'])

    # Assert
    assert result == mock_room
    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])


@pytest.mark.asyncio
async def test_get_room_details_not_found(mocker, mock_test_user):
    """
    测试获取不存在的房间详情
    - 模拟房间不存在的情况
    - 验证抛出RoomNotFoundException异常
    """
    # Arrange
    room_id = uuid.uuid4()

    # Mock CRUD operations - 房间不存在
    mock_get = mocker.patch("app.crud.room.get", return_value=None)

    # Act & Assert
    service = RoomService(db=None)
    with pytest.raises(RoomNotFoundException):
        await service.get_room_details(room_id, user_id=mock_test_user['public_id'])

    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])


# ==================== update_room_info Tests ====================

@pytest.mark.asyncio
async def test_update_room_success(mocker, mock_test_user):
    """
    测试成功更新房间信息
    - 模拟房间存在且未在直播
    - 验证更新成功并返回更新后的房间对象
    """
    # Arrange
    room_id = uuid.uuid4()
    mock_room = create_mock_room(room_id=room_id, user_id=mock_test_user['public_id'])
    updated_mock_room = create_mock_room(room_id=room_id, title="更新后的房间", user_id=mock_test_user['public_id'])
    room_update_data = create_room_update_data()

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_room)
    mock_is_live = mocker.patch("app.crud.room.is_live", return_value=False)
    mock_update = mocker.patch("app.crud.room.update", return_value=updated_mock_room)

    # Act
    service = RoomService(db=None)
    result = await service.update_room_info(room_id, room_update_data, user_id=mock_test_user['public_id'])

    # Assert
    assert result == updated_mock_room
    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])
    mock_is_live.assert_called_once_with(db=None, room_id=room_id)
    mock_update.assert_called_once_with(db=None, db_obj=mock_room, obj_in=room_update_data)


@pytest.mark.asyncio
async def test_update_room_not_found(mocker, mock_test_user):
    """
    测试更新不存在的房间
    - 模拟房间不存在的情况
    - 验证抛出RoomNotFoundException异常
    """
    # Arrange
    room_id = uuid.uuid4()
    room_update_data = create_room_update_data()

    # Mock CRUD operations - 房间不存在
    mock_get = mocker.patch("app.crud.room.get", return_value=None)

    # Act & Assert
    service = RoomService(db=None)
    with pytest.raises(RoomNotFoundException):
        await service.update_room_info(room_id, room_update_data, user_id=mock_test_user['public_id'])

    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])


@pytest.mark.asyncio
async def test_update_room_forbidden_when_live(mocker, mock_test_user):
    """
    测试更新正在直播的房间
    - 模拟房间存在但正在直播
    - 验证抛出ActionForbiddenException异常
    """
    # Arrange
    room_id = uuid.uuid4()
    mock_room = create_mock_room(room_id=room_id, user_id=mock_test_user['public_id'])
    room_update_data = create_room_update_data()

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_room)
    mock_is_live = mocker.patch("app.crud.room.is_live", return_value=True)  # 正在直播

    # Act & Assert
    service = RoomService(db=None)
    with pytest.raises(ActionForbiddenException) as exc_info:
        await service.update_room_info(room_id, room_update_data, user_id=mock_test_user['public_id'])

    assert str(exc_info.value) == "无法修改正在直播的房间"
    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])
    mock_is_live.assert_called_once_with(db=None, room_id=room_id)


# ==================== delete_room Tests ====================

@pytest.mark.asyncio
async def test_delete_room_success(mocker, mock_test_user):
    """
    测试成功删除房间
    - 模拟房间存在且未在直播
    - 验证删除成功并返回被删除的房间对象
    """
    # Arrange
    room_id = uuid.uuid4()
    mock_room = create_mock_room(room_id=room_id, user_id=mock_test_user['public_id'])

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_room)
    mock_is_live = mocker.patch("app.crud.room.is_live", return_value=False)
    mock_remove = mocker.patch("app.crud.room.remove", return_value=mock_room)

    # Act
    service = RoomService(db=None)
    result = await service.delete_room(room_id, user_id=mock_test_user['public_id'])

    # Assert
    assert result == mock_room
    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])
    mock_is_live.assert_called_once_with(db=None, room_id=room_id)
    mock_remove.assert_called_once_with(db=None, db_obj=mock_room)


@pytest.mark.asyncio
async def test_delete_room_not_found(mocker, mock_test_user):
    """
    测试删除不存在的房间
    - 模拟房间不存在的情况
    - 验证抛出RoomNotFoundException异常
    """
    # Arrange
    room_id = uuid.uuid4()

    # Mock CRUD operations - 房间不存在
    mock_get = mocker.patch("app.crud.room.get", return_value=None)

    # Act & Assert
    service = RoomService(db=None)
    with pytest.raises(RoomNotFoundException):
        await service.delete_room(room_id, user_id=mock_test_user['public_id'])

    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])


@pytest.mark.asyncio
async def test_delete_room_forbidden_when_live(mocker, mock_test_user):
    """
    测试删除正在直播的房间
    - 模拟房间存在但正在直播
    - 验证抛出ActionForbiddenException异常
    """
    # Arrange
    room_id = uuid.uuid4()
    mock_room = create_mock_room(room_id=room_id, user_id=mock_test_user['public_id'])

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_room)
    mock_is_live = mocker.patch("app.crud.room.is_live", return_value=True)  # 正在直播

    # Act & Assert
    service = RoomService(db=None)
    with pytest.raises(ActionForbiddenException) as exc_info:
        await service.delete_room(room_id, user_id=mock_test_user['public_id'])

    assert str(exc_info.value) == "无法删除正在直播的房间"
    mock_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])
    mock_is_live.assert_called_once_with(db=None, room_id=room_id)


# ==================== get_sub_venue_list Tests ====================

@pytest.mark.asyncio
async def test_get_sub_venue_list_success(mocker, mock_test_user):
    """
    测试成功获取分会场列表
    - 模拟主会场存在且有分会场
    - 验证返回正确的分会场列表和总数
    """
    # Arrange
    parent_room_id = uuid.uuid4()
    mock_parent_room = create_mock_room(room_id=parent_room_id, title="主会场", user_id=mock_test_user['public_id'])

    mock_sub_venues = [
        {
            'id': uuid.uuid4(),
            'title': '分会场1',
            'live_status': 'live',
            'current_session_id': uuid.uuid4()
        },
        {
            'id': uuid.uuid4(),
            'title': '分会场2',
            'live_status': None,
            'current_session_id': None
        }
    ]
    mock_total = 2

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_parent_room)
    mock_get_sub_venues = mocker.patch(
        "app.crud.room.get_sub_venues_with_live_status",
        return_value=(mock_sub_venues, mock_total)
    )

    # Act
    service = RoomService(db=None)
    result_venues, result_total = await service.get_sub_venue_list(
        parent_room_id, page=1, size=10, user_id=mock_test_user['public_id']
    )

    # Assert
    assert result_venues == mock_sub_venues
    assert result_total == mock_total
    mock_get.assert_called_once_with(db=None, room_id=parent_room_id, user_id=mock_test_user['public_id'])
    mock_get_sub_venues.assert_called_once_with(
        db=None, parent_room_id=parent_room_id, skip=0, limit=10, user_id=mock_test_user['public_id']
    )


@pytest.mark.asyncio
async def test_get_sub_venue_list_parent_not_found(mocker, mock_test_user):
    """
    测试获取分会场列表时主会场不存在
    - 模拟主会场不存在的情况
    - 验证抛出RoomNotFoundException异常
    """
    # Arrange
    parent_room_id = uuid.uuid4()

    # Mock CRUD operations - 主会场不存在
    mock_get = mocker.patch("app.crud.room.get", return_value=None)

    # Act & Assert
    service = RoomService(db=None)
    with pytest.raises(RoomNotFoundException):
        await service.get_sub_venue_list(parent_room_id, page=1, size=10, user_id=mock_test_user['public_id'])

    mock_get.assert_called_once_with(db=None, room_id=parent_room_id, user_id=mock_test_user['public_id'])


@pytest.mark.asyncio
async def test_get_sub_venue_list_pagination_calculation(mocker, mock_test_user):
    """
    测试分会场列表的分页计算
    - 验证skip值的正确计算
    - 测试不同的页码和页面大小参数
    """
    # Arrange
    parent_room_id = uuid.uuid4()
    mock_parent_room = create_mock_room(room_id=parent_room_id, title="主会场", user_id=mock_test_user['public_id'])
    mock_sub_venues = []
    mock_total = 0

    # Mock CRUD operations
    mock_get = mocker.patch("app.crud.room.get", return_value=mock_parent_room)
    mock_get_sub_venues = mocker.patch(
        "app.crud.room.get_sub_venues_with_live_status",
        return_value=(mock_sub_venues, mock_total)
    )

    # Act
    service = RoomService(db=None)
    await service.get_sub_venue_list(parent_room_id, page=3, size=20, user_id=mock_test_user['public_id'])

    # Assert
    # 验证skip计算: (page - 1) * size = (3 - 1) * 20 = 40
    mock_get_sub_venues.assert_called_once_with(
        db=None, parent_room_id=parent_room_id, skip=40, limit=20, user_id=mock_test_user['public_id']
    )


