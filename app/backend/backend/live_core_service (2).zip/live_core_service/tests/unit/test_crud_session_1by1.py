"""
LiveCore Service - Session CRUD Unit Tests

This module contains unit tests for the session CRUD operations,
testing each function in isolation to ensure data layer correctness.
"""

import pytest
import uuid
from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.crud import room as crud_room
from app.schemas.live_core import LiveRoomCreate, LiveRoomUpdate, LiveSessionCreate
from app.models.live_core import LiveRoom, LiveSession, LiveSessionStatus

from app.crud import session as crud_session



# Helper function to create a test room
async def create_test_room_old(db: AsyncSession) -> LiveRoom:
    """创建测试用的LiveRoom"""
    room = LiveRoom(
        title="测试房间",
        description="用于测试的房间",
        stream_key=f"test_key_{uuid.uuid4().hex[:8]}",
        is_private=False,
        record_by_default=True
    )
    db.add(room)
    await db.commit()
    await db.refresh(room)
    return room


async def create_test_room(db_session, test_user):
    """
    测试创建房间功能
    - 准备: 创建LiveRoomCreate对象
    - 执行: 调用crud.room.create()
    - 断言: 验证返回值和数据库状态
    """
    async for db in db_session:
            # 准备测试数据
            room_data = LiveRoomCreate(
                title="测试直播房间",
                description="这是一个测试房间",
                cover_url="https://example.com/cover.jpg",
                is_private=False,
                record_by_default=True,
                category_id=uuid.uuid4(),
                parent_room_id=None,
            )

            # 执行创建操作
            created_room = await crud_room.create(db=db, obj_in=room_data, user_id = test_user.public_id)

            return created_room


@pytest.mark.asyncio
async def test_create_with_stats(db_session, test_user):
    """
    测试create_with_stats函数
    - 功能：创建LiveSession并同时创建关联的SessionStatistics
    - 验证：Session创建成功，Statistics记录存在且默认值正确
    """
    async for db in db_session:
        async for user in test_user:
            # Arrange: 创建测试房间
            room = await create_test_room(db, user)

            # 准备会话创建数据
            start_time = datetime.now(timezone.utc)
            session_data = LiveSessionCreate(
                room_id=room.id,
                status=LiveSessionStatus.SCHEDULED,
                start_time=start_time,
                end_time=None,
                video_id=None
            )

            # Act: 调用create_with_stats
            created_session = await crud_session.create_with_stats(db=db, obj_in=session_data, user_id = test_user['public_id'])

            # Assert: 验证Session创建
            assert created_session is not None
            assert created_session.room_id == room.id
            assert created_session.status == LiveSessionStatus.SCHEDULED
            assert created_session.start_time == start_time
            assert created_session.end_time is None
            assert created_session.video_id is None

            # Assert: 验证Statistics创建
            # 查询SessionStatistics表
            stats_result = await db.execute(
                select(SessionStatistics).where(SessionStatistics.session_id == created_session.id)
            )
            stats_record = stats_result.scalar_one_or_none()

            assert stats_record is not None
            assert stats_record.session_id == created_session.id
            assert stats_record.peak_viewer_count == 0
            assert stats_record.total_viewer_count == 0
            assert stats_record.total_like_count == 0
            assert stats_record.total_share_count == 0

