"""
LiveCore Service - CRUD Room Unit Tests

This module contains detailed unit tests for the room CRUD operations.
"""

import pytest
import uuid
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession

from app.crud import room as crud_room
from app.schemas.live_core import LiveRoomCreate, LiveRoomUpdate
from app.models.live_core import LiveRoom, LiveSession, LiveSessionStatus

from ..conftest import test_user

@pytest.mark.asyncio
async def test_create_room(db_session, test_user):
    """
    测试创建房间功能
    - 准备: 创建LiveRoomCreate对象
    - 执行: 调用crud.room.create()
    - 断言: 验证返回值和数据库状态
    """
    async for db in db_session:
        async for user in test_user:
            # 准备测试数据
            room_data = LiveRoomCreate(
                title="测试直播房间",
                description="这是一个测试房间",
                cover_url="https://example.com/cover.jpg",
                is_private=False,
                record_by_default=True,
                category_id=uuid.uuid4(),
                parent_room_id=None,
                user_id=uuid.uuid4()
            )

            # 执行创建操作
            created_room = await crud_room.create(db=db, obj_in=room_data,user_id=user["public_id"])

            # 断言返回值
            assert created_room is not None
            assert created_room.title == room_data.title
            assert created_room.description == room_data.description
            assert created_room.cover_url == room_data.cover_url
            assert created_room.is_private == room_data.is_private
            assert created_room.record_by_default == room_data.record_by_default
            assert created_room.category_id == room_data.category_id
            assert created_room.user_id == room_data.user_id
            assert created_room.stream_key is not None
            assert created_room.stream_key.startswith("sk_live_")
            assert created_room.id is not None
            assert created_room.created_at is not None
            assert created_room.updated_at is not None

            # 验证数据库状态 - 重新从数据库获取记录
            db_room = await crud_room.get(db=db, room_id=created_room.id)
            assert db_room is not None
            assert db_room.id == created_room.id
            assert db_room.title == room_data.title
            assert db_room.description == room_data.description
            assert db_room.stream_key == created_room.stream_key


