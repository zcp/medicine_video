"""
LiveCore Service - SessionService Unit Tests

This module contains unit tests for the SessionService class,
testing all business logic in complete isolation using mocks.
All external dependencies (CRUD operations) are mocked.

数据模型关系说明：
- LiveSession 没有直接的 user_id 字段
- LiveSession 通过 room_id 关联到 LiveRoom
- LiveRoom 包含 user_id 字段
- 权限验证流程：session_id -> room_id -> LiveRoom.user_id -> 验证权限
"""

import pytest
import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock
from typing import List

from app.services.session_service import SessionService
from app.models.live_core import LiveSession, LiveRoom, LiveSessionStatus, SessionStatistics
from app.schemas.live_core import ScheduledSessionCreate, LiveSessionCreate, LiveSessionUpdate
from app.exceptions import (
    SessionNotFoundException,
    SessionActionForbiddenException,
    RoomNotFoundException
)


# ==================== Test Data Fixtures ====================

@pytest.fixture
def mock_test_user():
    """为单元测试提供模拟用户数据"""
    return {
        "public_id": "550e8400-e29b-41d4-a716-446655440000",
        "username": "test_user",
        "email": "test@example.com"
    }


# ==================== Test Helper Functions ====================

def create_mock_room(
    room_id: uuid.UUID = None,
    title: str = "测试房间",
    description: str = "测试描述",
    stream_key: str = "test_key",
    is_private: bool = False,
    record_by_default: bool = True,
    user_id: uuid.UUID = None
) -> LiveRoom:
    """创建模拟的LiveRoom对象"""
    if room_id is None:
        room_id = uuid.uuid4()

    mock_room = LiveRoom()
    mock_room.id = room_id
    mock_room.title = title
    mock_room.description = description
    mock_room.stream_key = stream_key
    mock_room.is_private = is_private
    mock_room.record_by_default = record_by_default
    mock_room.user_id = user_id
    mock_room.created_at = datetime.utcnow()
    mock_room.updated_at = datetime.utcnow()

    return mock_room


def create_mock_session(
    session_id: uuid.UUID = None,
    room_id: uuid.UUID = None,
    status: LiveSessionStatus = LiveSessionStatus.SCHEDULED,
    start_time: datetime = None,
    end_time: datetime = None,
    video_id: str = None
) -> LiveSession:
    """
    创建模拟的LiveSession对象
    
    注意：LiveSession 没有直接的 user_id 字段
    权限验证需要通过 room_id 关联到 LiveRoom 表来获取 user_id
    """
    if session_id is None:
        session_id = uuid.uuid4()
    if room_id is None:
        room_id = uuid.uuid4()
    if start_time is None:
        start_time = datetime.now(timezone.utc)

    mock_session = LiveSession()
    mock_session.id = session_id
    mock_session.room_id = room_id
    mock_session.status = status
    mock_session.start_time = start_time
    mock_session.end_time = end_time
    mock_session.video_id = video_id
    # 移除 user_id，因为 LiveSession 模型没有这个字段
    mock_session.created_at = datetime.utcnow()
    mock_session.updated_at = datetime.utcnow()

    return mock_session


# ==================== TestSessionServiceCreateScheduledSession ====================

class TestSessionServiceCreateScheduledSession:
    """测试创建计划场次的业务逻辑"""

    @pytest.mark.asyncio
    async def test_create_scheduled_session_success(self, mocker, mock_test_user):
        """
        测试成功创建计划场次
        - 验证房间存在
        - 正确构造LiveSessionCreate对象
        - 调用CRUD层创建会话和统计信息
        """
        # Arrange - 创建测试数据
        room_id = uuid.uuid4()
        session_id = uuid.uuid4()
        start_time = datetime.now(timezone.utc)

        # 创建模拟的房间对象
        mock_room = create_mock_room(
            room_id=room_id,
            title="测试房间",
            description="测试描述",
            stream_key="test_key",
            is_private=False,
            record_by_default=True,
            user_id=mock_test_user['public_id']
        )

        # 创建模拟的会话对象
        mock_session = create_mock_session(
            session_id=session_id,
            room_id=room_id,
            status=LiveSessionStatus.SCHEDULED,
            start_time=start_time,
            end_time=None,
            video_id=None
        )

        # 创建输入Schema
        session_in = ScheduledSessionCreate(start_time=start_time)

        # Mock CRUD操作
        mock_room_get = mocker.patch('app.crud.room.get', new_callable=AsyncMock)
        mock_room_get.return_value = mock_room

        mock_session_create = mocker.patch('app.crud.session.create_with_stats', new_callable=AsyncMock)
        mock_session_create.return_value = mock_session

        # Act - 执行测试
        service = SessionService(db=None)
        result = await service.create_scheduled_session(
            room_id=room_id,
            session_in=session_in,
            user_id=mock_test_user['public_id']
        )

        # Assert - 验证结果
        # 验证调用了房间查询
        mock_room_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])

        # 验证调用了会话创建，并检查传入的参数
        mock_session_create.assert_called_once()
        call_args = mock_session_create.call_args
        session_create_obj = call_args[1]['obj_in']  # 获取obj_in参数

        assert isinstance(session_create_obj, LiveSessionCreate)
        assert session_create_obj.room_id == room_id
        assert session_create_obj.status == LiveSessionStatus.SCHEDULED
        assert session_create_obj.start_time == start_time
        assert session_create_obj.end_time is None
        assert session_create_obj.video_id is None

        # 验证返回结果
        assert result == mock_session

    @pytest.mark.asyncio
    async def test_create_scheduled_session_room_not_found(self, mocker, mock_test_user):
        """
        测试房间不存在时的异常处理
        - 房间查询返回None
        - 抛出RoomNotFoundException
        """
        # Arrange
        room_id = uuid.uuid4()
        start_time = datetime.now(timezone.utc)
        session_in = ScheduledSessionCreate(start_time=start_time)

        # Mock房间不存在
        mock_room_get = mocker.patch('app.crud.room.get', new_callable=AsyncMock)
        mock_room_get.return_value = None

        # Act & Assert
        service = SessionService(db=None)
        with pytest.raises(RoomNotFoundException):
            await service.create_scheduled_session(
                room_id=room_id,
                session_in=session_in,
                user_id=mock_test_user['public_id']
            )

        # 验证只调用了房间查询，没有调用会话创建
        mock_room_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])


# ==================== TestSessionServiceUpdateScheduledSessionInfo ====================

class TestSessionServiceUpdateScheduledSessionInfo:
    """测试更新计划场次信息的业务逻辑"""

    @pytest.mark.asyncio
    async def test_update_session_info_success(self, mocker, mock_test_user):
        """
        测试成功更新计划场次信息
        - 会话存在且状态为SCHEDULED
        - 正确调用CRUD层更新操作
        """
        # Arrange
        session_id = uuid.uuid4()
        new_start_time = datetime.now(timezone.utc)

        # 创建模拟的会话对象（状态为SCHEDULED）
        mock_session = create_mock_session(
            session_id=session_id,
            room_id=uuid.uuid4(),
            status=LiveSessionStatus.SCHEDULED,
            start_time=datetime.now(timezone.utc),
            end_time=None,
            video_id=None
        )

        # 创建更新后的会话对象
        updated_session = create_mock_session(
            session_id=session_id,
            room_id=mock_session.room_id,
            status=LiveSessionStatus.SCHEDULED,
            start_time=new_start_time,
            end_time=None,
            video_id=None
        )

        session_update = LiveSessionUpdate(start_time=new_start_time)

        # Mock CRUD操作
        mock_session_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_session_get.return_value = mock_session

        mock_session_update = mocker.patch('app.crud.session.update', new_callable=AsyncMock)
        mock_session_update.return_value = updated_session

        # Act
        service = SessionService(db=None)
        result = await service.update_scheduled_session_info(
            session_id=session_id,
            session_update=session_update,
            user_id=mock_test_user['public_id']
        )

        # Assert
        mock_session_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])
        mock_session_update.assert_called_once_with(
            db=None,
            db_obj=mock_session,
            obj_in=session_update
        )
        assert result == updated_session

    @pytest.mark.asyncio
    async def test_update_session_info_not_found(self, mocker, mock_test_user):
        """
        测试更新不存在的会话
        - 会话查询返回None
        - 抛出SessionNotFoundException
        """
        # Arrange
        session_id = uuid.uuid4()
        session_update = LiveSessionUpdate(start_time=datetime.now(timezone.utc))

        # Mock会话不存在
        mock_session_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_session_get.return_value = None

        # Act & Assert
        service = SessionService(db=None)
        with pytest.raises(SessionNotFoundException):
            await service.update_scheduled_session_info(
                session_id=session_id,
                session_update=session_update,
                user_id=mock_test_user['public_id']
            )

        mock_session_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])

    @pytest.mark.asyncio
    async def test_update_session_info_forbidden_when_live(self, mocker, mock_test_user):
        """
        测试更新正在直播的场次
        - 会话状态为LIVE
        - 抛出SessionActionForbiddenException，错误消息正确
        """
        # Arrange
        session_id = uuid.uuid4()

        # 创建正在直播的会话对象
        mock_session = create_mock_session(
            session_id=session_id,
            room_id=uuid.uuid4(),
            status=LiveSessionStatus.LIVE,  # 状态为LIVE
            start_time=datetime.now(timezone.utc),
            end_time=None,
            video_id=None,
            #user_id=mock_test_user['public_id']
        )

        session_update = LiveSessionUpdate(start_time=datetime.now(timezone.utc))

        # Mock CRUD操作
        mock_session_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_session_get.return_value = mock_session

        # Act & Assert
        service = SessionService(db=None)
        with pytest.raises(SessionActionForbiddenException) as exc_info:
            await service.update_scheduled_session_info(
                session_id=session_id,
                session_update=session_update,
                user_id=mock_test_user['public_id']
            )

        # 验证异常消息
        assert exc_info.value.message == "无法修改正在直播或已结束场次的计划开始时间"
        mock_session_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])


# ==================== TestSessionServiceDeleteSession ====================

class TestSessionServiceDeleteSession:
    """测试删除场次的业务逻辑"""

    @pytest.mark.asyncio
    async def test_delete_session_success_when_finished(self, mocker, mock_test_user):
        """
        测试成功删除已结束的场次
        - 会话状态为FINISHED
        - 正确调用CRUD层删除操作
        """
        # Arrange
        session_id = uuid.uuid4()

        # 创建已结束的会话对象
        mock_session = create_mock_session(
            session_id=session_id,
            room_id=uuid.uuid4(),
            status=LiveSessionStatus.FINISHED,  # 状态为FINISHED
            start_time=datetime.now(timezone.utc),
            end_time=datetime.now(timezone.utc),
            video_id=None
        )

        # Mock CRUD操作
        mock_session_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_session_get.return_value = mock_session

        mock_session_remove = mocker.patch('app.crud.session.remove', new_callable=AsyncMock)
        mock_session_remove.return_value = mock_session

        # Act
        service = SessionService(db=None)
        result = await service.delete_session(session_id=session_id, user_id=mock_test_user['public_id'])

        # Assert
        mock_session_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])
        mock_session_remove.assert_called_once_with(db=None, db_obj=mock_session)
        assert result == mock_session

    @pytest.mark.asyncio
    async def test_delete_session_fails_when_live(self, mocker, mock_test_user):
        """
        测试删除正在直播的场次失败
        - 会话状态为LIVE
        - 抛出SessionActionForbiddenException，错误消息正确
        """
        # Arrange
        session_id = uuid.uuid4()

        # 创建正在直播的会话对象
        mock_session = create_mock_session(
            session_id=session_id,
            room_id=uuid.uuid4(),
            status=LiveSessionStatus.LIVE,  # 状态为LIVE
            start_time=datetime.now(timezone.utc),
            end_time=None,
            video_id=None
        )

        # Mock CRUD操作
        mock_session_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_session_get.return_value = mock_session

        # Act & Assert
        service = SessionService(db=None)
        with pytest.raises(SessionActionForbiddenException) as exc_info:
            await service.delete_session(session_id=session_id, user_id=mock_test_user['public_id'])

        # 验证异常消息
        assert exc_info.value.message == "无法删除正在直播的场次"
        mock_session_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])

    @pytest.mark.asyncio
    async def test_delete_session_not_found(self, mocker, mock_test_user):
        """
        测试删除不存在的会话
        - 会话查询返回None
        - 抛出SessionNotFoundException
        """
        # Arrange
        session_id = uuid.uuid4()

        # Mock会话不存在
        mock_session_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_session_get.return_value = None

        # Act & Assert
        service = SessionService(db=None)
        with pytest.raises(SessionNotFoundException):
            await service.delete_session(session_id=session_id, user_id=mock_test_user['public_id'])

        mock_session_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])


# ==================== TestSessionServiceGetSessionsByRoom ====================

class TestSessionServiceGetSessionsByRoom:
    """测试获取房间场次列表的业务逻辑"""

    @pytest.mark.asyncio
    async def test_get_sessions_by_room_success(self, mocker, mock_test_user):
        """
        测试成功获取房间场次列表
        - 验证房间存在
        - 正确计算skip值
        - 返回正确的分页数据
        """
        # Arrange
        room_id = uuid.uuid4()
        page = 2
        size = 5
        expected_skip = (page - 1) * size  # = 5

        # 创建模拟数据
        mock_room = create_mock_room(
            room_id=room_id,
            title="测试房间",
            description="测试描述",
            stream_key="test_key",
            is_private=False,
            record_by_default=True,
            user_id=mock_test_user['public_id']
        )

        mock_sessions = [
            create_mock_session(
                session_id=uuid.uuid4(),  # 修复：使用 session_id 而不是 id
                room_id=room_id,
                status=LiveSessionStatus.SCHEDULED,
                start_time=datetime.now(timezone.utc),
                end_time=None,
                video_id=None
            )
        ]
        mock_total = 1

        # Mock CRUD操作
        mock_room_get = mocker.patch('app.crud.room.get', new_callable=AsyncMock)
        mock_room_get.return_value = mock_room

        mock_get_multi = mocker.patch('app.crud.session.get_multi_by_room_and_total', new_callable=AsyncMock)
        mock_get_multi.return_value = (mock_sessions, mock_total)

        # Act
        service = SessionService(db=None)
        sessions, total = await service.get_sessions_by_room(
            room_id=room_id,
            page=page,
            size=size,
            user_id=mock_test_user['public_id']
        )

        # Assert
        mock_room_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])
        mock_get_multi.assert_called_once_with(
            db=None,
            room_id=room_id,
            skip=expected_skip,
            limit=size,
            user_id=mock_test_user['public_id']
        )
        assert sessions == mock_sessions
        assert total == mock_total

    @pytest.mark.asyncio
    async def test_get_sessions_by_room_room_not_found(self, mocker, mock_test_user):
        """
        测试获取不存在房间的场次列表
        - 房间查询返回None
        - 抛出RoomNotFoundException
        """
        # Arrange
        room_id = uuid.uuid4()
        page = 1
        size = 10

        # Mock房间不存在
        mock_room_get = mocker.patch('app.crud.room.get', new_callable=AsyncMock)
        mock_room_get.return_value = None

        # Act & Assert
        service = SessionService(db=None)
        with pytest.raises(RoomNotFoundException):
            await service.get_sessions_by_room(
                room_id=room_id,
                page=page,
                size=size,
                user_id=mock_test_user['public_id']
            )

        mock_room_get.assert_called_once_with(db=None, room_id=room_id, user_id=mock_test_user['public_id'])


# ==================== TestSessionServiceGetSessionDetails ====================

class TestSessionServiceGetSessionDetails:
    """测试获取会话详情的业务逻辑"""

    @pytest.mark.asyncio
    async def test_get_session_details_success(self, mocker, mock_test_user):
        """
        测试成功获取会话详情（包含统计信息）
        - 会话存在
        - 返回包含统计信息的会话对象
        """
        # Arrange
        session_id = uuid.uuid4()

        # 创建包含统计信息的会话对象
        mock_statistics = SessionStatistics(
            id=uuid.uuid4(),
            session_id=session_id,
            peak_viewer_count=100,
            total_viewer_count=500,
            total_like_count=50,
            total_share_count=10
        )

        mock_session = create_mock_session(
            session_id=session_id,
            room_id=uuid.uuid4(),
            status=LiveSessionStatus.FINISHED,
            start_time=datetime.now(timezone.utc),
            end_time=datetime.now(timezone.utc),
            video_id=None,
            #user_id=mock_test_user['public_id']  # 添加 user_id
        )
        mock_session.statistics = mock_statistics

        # Mock CRUD操作 - 需要 Mock 两个方法调用
        # 1. 权限验证：通过 session.room_id 查询 LiveRoom 来验证 user_id
        mock_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_get.return_value = mock_session

        # 2. 获取统计信息：不需要 user_id 参数，因为权限已经验证过了
        mock_get_with_stats = mocker.patch('app.crud.session.get_with_stats', new_callable=AsyncMock)
        mock_get_with_stats.return_value = mock_session

        # Act
        service = SessionService(db=None)
        result = await service.get_session_details(session_id=session_id, user_id=mock_test_user['public_id'])

        # Assert
        # 验证权限验证调用：通过 session.room_id 查询 LiveRoom 来验证 user_id
        mock_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])
        # 验证获取统计信息调用：不需要 user_id 参数，因为权限已经验证过了
        mock_get_with_stats.assert_called_once_with(db=None, session_id=session_id)
        assert result == mock_session
        assert result.statistics == mock_statistics


    @pytest.mark.asyncio
    async def test_get_session_details_not_found(self, mocker, mock_test_user):
        """
        测试获取不存在的会话详情
        - 会话查询返回None
        - 抛出SessionNotFoundException
        """
        # Arrange
        session_id = uuid.uuid4()

        # Mock会话不存在 - 修复：Mock 正确的路径
        mock_get = mocker.patch('app.crud.session.get', new_callable=AsyncMock)
        mock_get.return_value = None

        # Act & Assert
        service = SessionService(db=None)
        with pytest.raises(SessionNotFoundException):
            await service.get_session_details(session_id=session_id, user_id=mock_test_user['public_id'])

        mock_get.assert_called_once_with(db=None, session_id=session_id, user_id=mock_test_user['public_id'])