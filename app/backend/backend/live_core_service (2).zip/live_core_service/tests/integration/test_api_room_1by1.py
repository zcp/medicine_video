"""
LiveCore Service - Room API Integration Tests

This module contains integration tests for the room API endpoints,
focusing on external API contract and critical business logic flows.
"""

import pytest
import uuid
import json
from datetime import datetime, timezone
from httpx import AsyncClient
from sqlalchemy import text, select

from app.models.live_core import LiveSession, LiveSessionStatus

from backend.live_core_service.tests.integration.test_api_session import create_test_room_via_api, \
    create_test_room_in_db

