"""
LiveCore Service - Room API Integration Tests

This module contains integration tests for the room API endpoints,
focusing on external API contract and critical business logic flows.
"""

import pytest
import uuid
import json
import os
from datetime import datetime
from httpx import AsyncClient

from app.models.live_core import LiveSession, LiveSessionStatus


@pytest.mark.asyncio
async def test_create_room_success(async_client, db_session, auth_headers):
    """
    测试成功创建房间
    - 发送POST请求到/api/v1/rooms
    - 验证响应结构和状态码
    - 验证返回数据的正确性
    """
    # 准备请求数据
    room_data = {
        "title": "新产品发布会直播",
        "description": "介绍我们即将发布的 v3.0 版本。",
        "record_by_default": True,
        "is_private": False
    }
    
    # 发送POST请求
    async for client in async_client:
        response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        
        # 断言顶层结构
        assert response.status_code == 200
        response_json = response.json()
        assert isinstance(response_json, dict)
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        assert "timestamp" in response_json
        
        # 断言响应值
        assert response_json["code"] == 200
        assert response_json["message"] == "success"
        
        # 断言data对象结构
        data = response_json["data"]
        assert isinstance(data, dict)
        assert "id" in data
        assert "title" in data
        assert "stream_key" in data
        assert "record_by_default" in data
        assert "created_at" in data
        
        # 断言data内容
        assert data["title"] == room_data["title"]
        assert data["record_by_default"] == room_data["record_by_default"]
        assert data["stream_key"].startswith("sk_live_")
        assert uuid.UUID(data["id"])  # 验证ID是有效的UUID
        break


@pytest.mark.asyncio
async def test_create_room_with_invalid_parent(async_client, auth_headers):
    """
    测试创建房间时指定不存在的父房间
    - 发送POST请求，包含不存在的parent_room_id
    - 验证返回400错误和正确的错误信息
    """
    # 准备请求数据，包含不存在的parent_room_id
    room_data = {
        "title": "分会场测试",
        "description": "测试分会场创建",
        "parent_room_id": str(uuid.uuid4())  # 随机UUID，不存在
    }
    
    # 发送POST请求
    async for client in async_client:
        response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        
        # 断言错误响应结构
        assert response.status_code == 400
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        assert "timestamp" in response_json
        
        # 断言错误信息
        assert response_json["code"] == 2004
        assert response_json["message"] == "主会场不存在"
        break


@pytest.mark.asyncio
async def test_get_rooms_success(async_client, db_session, auth_headers):
    """
    测试成功获取房间列表
    - 先创建几个房间
    - 发送GET请求到/api/v1/rooms
    - 验证响应结构和分页信息
    """
    async for client in async_client:
        # 先创建几个房间
        for i in range(3):
            room_data = {
                "title": f"测试房间{i}",
                "description": f"测试描述{i}"
            }
            await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        
        # 发送GET请求
        response = await client.get("/api/v1/rooms?page=1&size=2", headers=auth_headers)
        
        # 断言顶层结构
        assert response.status_code == 200
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        assert "timestamp" in response_json
        
        # 断言响应值
        assert response_json["code"] == 200
        assert response_json["message"] == "success"
        
        # 断言data结构（分页响应）
        data = response_json["data"]
        assert "total" in data
        assert "page" in data
        assert "size" in data
        assert "items" in data
        
        assert data["page"] == 1
        assert data["size"] == 2
        assert data["total"] >= 3  # 至少有我们创建的3个房间
        assert len(data["items"]) == 2  # 限制返回2个
        
        # 验证items结构
        for item in data["items"]:
            assert "id" in item
            assert "title" in item
            assert "created_at" in item
        break


@pytest.mark.asyncio
async def test_get_room_success(async_client, auth_headers):
    """
    测试成功获取单个房间详情
    - 先创建一个房间
    - 发送GET请求到/api/v1/rooms/{room_id}
    - 验证响应结构和内容
    """
    async for client in async_client:
        # 先创建一个房间
        room_data = {
            "title": "详情测试房间",
            "description": "用于测试获取详情",
            "is_private": True
        }
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 发送GET请求
        response = await client.get(f"/api/v1/rooms/{room_id}", headers=auth_headers)
        
        # 断言顶层结构
        assert response.status_code == 200
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        
        # 断言响应值
        assert response_json["code"] == 200
        assert response_json["message"] == "success"
        
        # 断言data内容
        data = response_json["data"]
        assert data["id"] == room_id
        assert data["title"] == room_data["title"]
        assert data["description"] == room_data["description"]
        assert data["is_private"] == room_data["is_private"]
        assert "stream_key" in data
        assert "created_at" in data
        break


@pytest.mark.asyncio
async def test_get_room_not_found(async_client, auth_headers):
    """
    测试获取不存在的房间
    - 发送GET请求到/api/v1/rooms/{random_uuid}
    - 验证返回404错误和正确的错误信息
    """
    # 生成随机UUID
    random_id = str(uuid.uuid4())
    
    # 发送GET请求
    async for client in async_client:
        response = await client.get(f"/api/v1/rooms/{random_id}", headers=auth_headers)
        
        # 断言错误响应结构
        assert response.status_code == 404
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        assert "timestamp" in response_json
        
        # 断言错误信息
        assert response_json["code"] == 2001
        assert response_json["message"] == "资源不存在"
        assert response_json["data"]["resource"] == "Room"
        assert response_json["data"]["id"] == random_id
        break


@pytest.mark.asyncio
async def test_update_room_success(async_client, auth_headers):
    """
    测试成功更新房间信息
    - 先创建一个房间
    - 发送PATCH请求更新房间信息
    - 验证响应结构和更新内容
    """
    async for client in async_client:
        # 先创建一个房间
        room_data = {
            "title": "原始标题",
            "description": "原始描述"
        }
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 准备更新数据
        update_data = {
            "title": "新产品发布会直播（已更新）",
            "description": "更新：我们将额外演示 AI 功能。"
        }
        
        # 发送PATCH请求
        response = await client.patch(f"/api/v1/rooms/{room_id}", json=update_data, headers=auth_headers)
        
        # 断言顶层结构
        assert response.status_code == 200
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        
        # 断言响应值
        assert response_json["code"] == 200
        assert response_json["message"] == "success"
        
        # 断言更新内容
        data = response_json["data"]
        assert data["id"] == room_id
        assert data["title"] == update_data["title"]
        assert data["description"] == update_data["description"]
        assert "updated_at" in data
        break


@pytest.mark.asyncio
async def test_update_room_forbidden_when_live(async_client, db_session, auth_headers):
    """
    测试更新正在直播的房间时返回禁止错误
    - 先创建一个房间
    - 在数据库中为该房间创建LIVE状态的会话
    - 发送PATCH请求尝试更新
    - 验证返回403错误
    """
    async for client in async_client:
        # 先创建一个房间
        room_data = {
            "title": "直播中房间",
            "description": "这个房间正在直播"
        }
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 在数据库中创建LIVE状态的会话
        async for db in db_session:
            live_session = LiveSession(
                room_id=uuid.UUID(room_id),
                status=LiveSessionStatus.LIVE,
                start_time=datetime.now()
            )
            db.add(live_session)
            await db.commit()
            break
        
        # 准备更新数据
        update_data = {
            "title": "尝试更新直播中的房间"
        }
        
        # 发送PATCH请求
        response = await client.patch(f"/api/v1/rooms/{room_id}", json=update_data, headers=auth_headers)
        
        # 断言错误响应结构
        assert response.status_code == 403
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        
        # 断言错误信息
        assert response_json["code"] == 2002
        assert response_json["message"] == "业务逻辑错误"
        assert "无法修改正在直播的房间" in response_json["data"]["error"]
        break


@pytest.mark.asyncio
async def test_delete_room_success(async_client, auth_headers):
    """
    测试成功删除房间
    - 先创建一个房间
    - 发送DELETE请求删除房间
    - 验证响应结构和删除状态
    """
    async for client in async_client:
        # 先创建一个房间
        room_data = {
            "title": "待删除房间",
            "description": "这个房间将被删除"
        }
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 发送DELETE请求
        response = await client.delete(f"/api/v1/rooms/{room_id}", headers=auth_headers)
        
        # 断言成功响应结构
        assert response.status_code == 200
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        
        # 断言响应值
        assert response_json["code"] == 200
        assert response_json["message"] == "success"
        assert response_json["data"]["id"] == room_id
        assert response_json["data"]["status"] == "deleted"
        
        # 验证房间确实被删除 - 再次获取应该返回404
        get_response = await client.get(f"/api/v1/rooms/{room_id}", headers=auth_headers)
        assert get_response.status_code == 404
        break


@pytest.mark.asyncio
async def test_delete_room_forbidden_when_live(async_client, db_session, auth_headers):
    """
    测试删除正在直播的房间时返回禁止错误
    - 先创建一个房间
    - 在数据库中为该房间创建LIVE状态的会话
    - 发送DELETE请求尝试删除
    - 验证返回403错误
    """
    async for client in async_client:
        # 先创建一个房间
        room_data = {
            "title": "直播中待删除房间",
            "description": "这个房间正在直播，不能删除"
        }
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 在数据库中创建LIVE状态的会话
        async for db in db_session:
            live_session = LiveSession(
                room_id=uuid.UUID(room_id),
                status=LiveSessionStatus.LIVE,
                start_time=datetime.now()
            )
            db.add(live_session)
            await db.commit()
            break
        
        # 发送DELETE请求
        response = await client.delete(f"/api/v1/rooms/{room_id}", headers=auth_headers)
        
        # 断言错误响应结构
        assert response.status_code == 403
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        
        # 断言错误信息
        assert response_json["code"] == 2003
        assert response_json["message"] == "业务逻辑错误"
        assert "无法删除正在直播的房间" in response_json["data"]["error"]
        break


@pytest.mark.asyncio
async def test_get_sub_venues_success(async_client, db_session, auth_headers):
    """
    测试成功获取分会场列表
    - 先创建主会场和分会场
    - 发送GET请求到/api/v1/rooms/{room_id}/sub-venues
    - 验证响应结构和分会场信息
    """
    async for client in async_client:
        # 先创建主会场
        main_room_data = {
            "title": "主会场",
            "description": "主要会场"
        }
        main_response = await client.post("/api/v1/rooms", json=main_room_data, headers=auth_headers)
        assert main_response.status_code == 200
        main_room_id = main_response.json()["data"]["id"]
        
        # 创建分会场
        sub_room_data = {
            "title": "分会场1",
            "description": "第一个分会场",
            "parent_room_id": main_room_id
        }
        sub_response = await client.post("/api/v1/rooms", json=sub_room_data, headers=auth_headers)
        assert sub_response.status_code == 200
        
        # 发送GET请求获取分会场列表
        response = await client.get(f"/api/v1/rooms/{main_room_id}/sub-venues", headers=auth_headers)
        
        # 断言顶层结构
        assert response.status_code == 200
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        
        # 断言响应值
        assert response_json["code"] == 200
        assert response_json["message"] == "success"
        
        # 断言data结构（分页响应）
        data = response_json["data"]
        assert "total" in data
        assert "page" in data
        assert "size" in data
        assert "items" in data
        
        assert data["total"] >= 1  # 至少有我们创建的1个分会场
        assert len(data["items"]) >= 1
        
        # 验证分会场信息
        found_sub_venue = False
        for item in data["items"]:
            assert "id" in item
            assert "title" in item
            assert "live_status" in item
            assert "current_session_id" in item
            
            if item["title"] == "分会场1":
                found_sub_venue = True
                assert item["live_status"] is None  # 没有直播会话
                assert item["current_session_id"] is None
        
        assert found_sub_venue, "应该找到创建的分会场"
        break


@pytest.mark.asyncio
async def test_get_sub_venues_not_found(async_client, auth_headers):
    """
    测试获取不存在主会场的分会场列表
    - 发送GET请求到/api/v1/rooms/{random_uuid}/sub-venues
    - 验证返回404错误
    """
    # 生成随机UUID
    random_id = str(uuid.uuid4())
    
    # 发送GET请求
    async for client in async_client:
        response = await client.get(f"/api/v1/rooms/{random_id}/sub-venues", headers=auth_headers)
        
        # 断言错误响应结构
        assert response.status_code == 404
        response_json = response.json()
        assert response_json["code"] == 2001
        assert response_json["message"] == "资源不存在"
        break


@pytest.mark.asyncio
async def test_api_response_timestamp_format(async_client, auth_headers):
    """
    测试API响应中timestamp字段的格式
    - 发送任意请求
    - 验证timestamp字段是ISO 8601格式
    """
    room_data = {
        "title": "时间戳测试房间",
        "description": "用于测试时间戳格式"
    }
    
    async for client in async_client:
        response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert response.status_code == 200
        
        response_json = response.json()
        timestamp = response_json["timestamp"]
        
        # 验证timestamp是有效的ISO 8601格式
        try:
            datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        except ValueError:
            pytest.fail(f"Timestamp {timestamp} is not in valid ISO 8601 format")
        break


@pytest.mark.asyncio
async def test_api_error_response_structure(async_client, auth_headers):
    """
    测试API错误响应的结构一致性
    - 发送会产生错误的请求
    - 验证错误响应包含所有必需字段
    """
    # 发送会产生404错误的请求
    random_id = str(uuid.uuid4())
    async for client in async_client:
        response = await client.get(f"/api/v1/rooms/{random_id}", headers=auth_headers)
        
        assert response.status_code == 404
        response_json = response.json()
        
        # 验证错误响应结构
        required_fields = ["code", "message", "data", "timestamp"]
        for field in required_fields:
            assert field in response_json, f"错误响应缺少必需字段: {field}"
        
        # 验证字段类型
        assert isinstance(response_json["code"], int)
        assert isinstance(response_json["message"], str)
        assert isinstance(response_json["data"], dict)
        assert isinstance(response_json["timestamp"], str)
        break


# ==================== 以下是新增的封面上传测试 ====================

@pytest.mark.asyncio
async def test_upload_room_cover_success(async_client, auth_headers):
    """
    测试成功上传房间封面
    - 先创建一个房间
    - 上传有效的图片文件
    - 验证响应包含room_id和cover_url
    - 验证cover_url格式正确
    """
    from io import BytesIO
    
    async for client in async_client:
        # 准备请求数据 - 创建房间
        room_data = {
            "title": "封面上传测试房间",
            "description": "用于测试封面上传功能"
        }
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 准备文件
        image_content = b"fake image content"
        files = {"file": ("test_cover.jpg", BytesIO(image_content), "image/jpeg")}
        
        # 发送POST请求上传封面
        response = await client.post(
            f"/api/v1/rooms/{room_id}/cover",
            files=files,
            headers=auth_headers
        )
        
        # 断言顶层结构
        assert response.status_code == 200
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        assert "timestamp" in response_json
        
        # 断言响应值
        assert response_json["code"] == 200
        assert response_json["message"] == "success"
        
        # 断言data内容
        data = response_json["data"]
        assert data["room_id"] == room_id
        assert "cover_url" in data
        assert data["cover_url"] is not None
        assert "/media/rooms/" in data["cover_url"]
        assert room_id in data["cover_url"]
        assert "cover_" in data["cover_url"]
        
        break


@pytest.mark.asyncio
async def test_upload_room_cover_invalid_file_type(async_client, auth_headers):
    """
    测试上传不支持的文件类型
    - 创建一个房间
    - 尝试上传.txt文件
    - 验证：返回400错误，错误消息包含"不支持的文件类型"
    """
    from io import BytesIO
    
    async for client in async_client:
        # 准备 - 创建房间
        room_data = {"title": "测试房间", "description": "测试上传错误文件类型"}
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 准备无效的文件（.txt）
        files = {"file": ("document.txt", BytesIO(b"text content"), "text/plain")}
        
        # 发送POST请求上传
        response = await client.post(
            f"/api/v1/rooms/{room_id}/cover",
            files=files,
            headers=auth_headers
        )
        
        # 断言错误响应
        assert response.status_code in [400, 500]  # 可能是400或500
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        
        break


@pytest.mark.asyncio
async def test_upload_room_cover_file_size_exceeded(async_client, auth_headers):
    """
    测试上传超过大小限制的文件
    - 创建一个房间
    - 尝试上传超过5MB的文件
    - 验证：返回400错误，错误消息包含"文件大小超出限制"
    """
    from io import BytesIO
    
    async for client in async_client:
        # 准备 - 创建房间
        room_data = {"title": "测试房间", "description": "测试大文件上传"}
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 准备超大文件（> 5MB）
        large_content = b"x" * (5 * 1024 * 1024 + 1)
        files = {"file": ("large.jpg", BytesIO(large_content), "image/jpeg")}
        
        # 发送POST请求上传
        response = await client.post(
            f"/api/v1/rooms/{room_id}/cover",
            files=files,
            headers=auth_headers
        )
        
        # 断言错误响应
        assert response.status_code in [400, 500]
        response_json = response.json()
        assert "code" in response_json
        
        break


@pytest.mark.asyncio
async def test_upload_room_cover_room_not_found(async_client, auth_headers):
    """
    测试为不存在的房间上传封面
    - 使用随机UUID作为room_id
    - 尝试上传有效的图片文件
    - 验证：返回404错误，错误码2001
    """
    from io import BytesIO
    
    async for client in async_client:
        # 准备 - 使用随机UUID（不存在的房间）
        random_room_id = str(uuid.uuid4())
        
        # 准备有效的文件
        files = {"file": ("test.jpg", BytesIO(b"fake content"), "image/jpeg")}
        
        # 发送POST请求上传
        response = await client.post(
            f"/api/v1/rooms/{random_room_id}/cover",
            files=files,
            headers=auth_headers
        )
        
        # 断言错误响应结构
        assert response.status_code == 404
        response_json = response.json()
        assert "code" in response_json
        assert "message" in response_json
        assert "data" in response_json
        
        # 断言错误信息
        assert response_json["code"] == 2001
        assert response_json["message"] == "资源不存在"
        assert response_json["data"]["resource"] == "Room"
        
        break


@pytest.mark.asyncio
async def test_upload_room_cover_permission_denied(async_client, auth_headers):
    """
    测试用户无权为他人的房间上传封面
    - 用户A创建房间
    - 用户B尝试上传封面
    - 验证：返回403错误，错误码2003
    """
    from io import BytesIO
    import time
    import jwt
    
    async for client in async_client:
        # 准备 - 用户A创建房间
        room_data = {"title": "用户A的房间", "description": "测试权限"}
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 创建另一个用户B的JWT token
        other_user_id = str(uuid.uuid4())
        other_user_payload = {
            "user_id": other_user_id,
            "sub": other_user_id,
            "email": "other@example.com",
            "exp": int(time.time()) + 3600
        }
        secret_key = os.getenv("JWT_SECRET_KEY", "my-key")
        other_token = jwt.encode(other_user_payload, secret_key, algorithm="HS256")
        other_auth_headers = {"Authorization": f"Bearer {other_token}"}
        
        # 准备文件
        files = {"file": ("test.jpg", BytesIO(b"fake content"), "image/jpeg")}
        
        # 用户B尝试上传封面
        response = await client.post(
            f"/api/v1/rooms/{room_id}/cover",
            files=files,
            headers=other_auth_headers
        )
        
        # 断言错误响应
        assert response.status_code == 404  # 由于user_id过滤，返回404（房间不存在）
        response_json = response.json()
        assert response_json["code"] == 2001
        
        break


@pytest.mark.asyncio
async def test_upload_room_cover_replace_old_cover(async_client, auth_headers):
    """
    测试上传新封面替换旧封面
    - 创建房间并第一次上传封面
    - 第二次上传新封面
    - 验证：返回新的cover_url（与第一次不同）
    """
    from io import BytesIO
    import time
    
    async for client in async_client:
        # 准备 - 创建房间
        room_data = {"title": "测试替换封面房间", "description": "测试封面替换"}
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 第一次上传封面
        files1 = {"file": ("cover1.jpg", BytesIO(b"first cover"), "image/jpeg")}
        response1 = await client.post(
            f"/api/v1/rooms/{room_id}/cover",
            files=files1,
            headers=auth_headers
        )
        assert response1.status_code == 200
        first_cover_url = response1.json()["data"]["cover_url"]
        
        # 等待一秒确保时间戳不同
        time.sleep(1)
        
        # 第二次上传封面
        files2 = {"file": ("cover2.jpg", BytesIO(b"second cover"), "image/jpeg")}
        response2 = await client.post(
            f"/api/v1/rooms/{room_id}/cover",
            files=files2,
            headers=auth_headers
        )
        
        # 断言第二次上传成功
        assert response2.status_code == 200
        second_cover_url = response2.json()["data"]["cover_url"]
        
        # 验证URL不同（时间戳不同）
        assert second_cover_url != first_cover_url
        assert room_id in second_cover_url
        
        break


@pytest.mark.asyncio
async def test_get_rooms_list_includes_cover_url(async_client, auth_headers):
    """
    测试获取房间列表响应包含cover_url字段
    - 创建一个房间（不上传封面）
    - 获取房间列表
    - 验证：每个房间对象都包含cover_url字段
    """
    async for client in async_client:
        # 准备 - 创建房间
        room_data = {"title": "测试房间", "description": "测试响应字段"}
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        
        # 发送GET请求获取房间列表
        response = await client.get("/api/v1/rooms?page=1&size=10", headers=auth_headers)
        
        # 断言响应成功
        assert response.status_code == 200
        response_json = response.json()
        assert response_json["code"] == 200
        
        # 验证每个房间都包含cover_url字段
        data = response_json["data"]
        assert "items" in data
        assert len(data["items"]) > 0
        
        for item in data["items"]:
            assert "cover_url" in item
            # cover_url可以为null或有效URL
        
        break


@pytest.mark.asyncio
async def test_get_room_detail_includes_cover_url(async_client, auth_headers):
    """
    测试获取房间详情响应包含cover_url字段
    - 创建一个房间（不上传封面）
    - 获取房间详情
    - 验证：响应包含cover_url字段，初始值为null
    """
    async for client in async_client:
        # 准备 - 创建房间
        room_data = {"title": "测试房间详情", "description": "测试响应字段"}
        create_response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
        assert create_response.status_code == 200
        room_id = create_response.json()["data"]["id"]
        
        # 发送GET请求获取房间详情
        response = await client.get(f"/api/v1/rooms/{room_id}", headers=auth_headers)
        
        # 断言响应成功
        assert response.status_code == 200
        response_json = response.json()
        assert response_json["code"] == 200
        
        # 验证包含cover_url字段
        data = response_json["data"]
        assert "cover_url" in data
        # 初始值应该为null（未上传封面）
        
        break 