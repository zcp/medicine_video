"""
LiveCore Service - SRS Internal Callbacks Integration Tests

This module contains comprehensive integration tests for SRS callback endpoints,
verifying API responses, database state changes, and background task execution.
"""
import httpx
import pytest
import uuid
from datetime import datetime, timezone
from unittest.mock import patch

from app.models.live_core import LiveSessionStatus
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

from app.core.config import settings
from sqlalchemy.orm import sessionmaker


# ============================================================================
# Test Helper Functions (假设这些函数在conftest.py或其他地方定义)
# ============================================================================

async def create_test_room(db):
    """在数据库中创建一个测试用的LiveRoom"""
    from app.crud import room as crud_room
    from app.schemas.live_core import LiveRoomCreate
    
    # 生成一个测试用户ID
    test_user_id = uuid.uuid4()
    
    room_create = LiveRoomCreate(
        title="Test Room",
        description="Test room for SRS callbacks",
        is_private=False,
        record_by_default=True
    )
    return await crud_room.create(db, obj_in=room_create, user_id=test_user_id)


async def create_test_session(db, room_id: uuid.UUID, status: LiveSessionStatus):
    """在数据库中创建一个具有指定状态的LiveSession"""
    from app.crud import session as crud_session
    from app.schemas.live_core import LiveSessionCreate
    
    session_create = LiveSessionCreate(
        room_id=room_id,
        status=status,
        start_time=datetime.now(timezone.utc),
        end_time=None,
        video_id=None
    )
    return await crud_session.create_with_stats(db, obj_in=session_create)


# tests/tasks/test_session_processing.py
import pytest
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from unittest.mock import patch

# 导入您的异步任务和模型/CRUD
from app.tasks.session_processing import post_stream_processing_task
from app.models.live_core import LiveSessionStatus
from app.crud import session as crud_session
# 注意：create_test_room 和 create_test_session 函数已在此文件中定义，无需从其他文件导入


# ============================================================================
# on_unpublish 回调测试用例 (重构版)
# ============================================================================

@pytest.mark.asyncio
async def test_on_unpublish_updates_status_and_dispatches_task(
    async_client: httpx.AsyncClient,
    db_session: AsyncSession,
    mocker  # 引入 mocker fixture
):
    """
    测试 on_unpublish 接口的核心职责：
    1. 正确更新会话状态为 'finished'。
    2. 成功派发后台处理任务。
    """
    async for client in async_client:
        async for db in db_session:

            # Arrange: 创建一个 live 状态的会话
            test_room = await create_test_room(db)
            live_session = await create_test_session(db, test_room.id, LiveSessionStatus.LIVE)
            original_session_id = live_session.id

            # Arrange: 使用 mocker "监听" Celery 任务的 .delay() 方法
            # 我们并不实际执行任务，只验证它是否被正确地调用了
            mock_task_delay = mocker.patch(
                "app.services.srs_callback_service.post_stream_processing_task.delay"
            )

            # 准备请求数据
            payload = {
                "action": "on_unpublish",
                "client_id": "test_client_end",
                "ip": "192.168.1.104",
                "vhost": "__defaultVhost__",
                "app": "live",
                "stream": test_room.stream_key
            }

            # Act: 调用 on_unpublish 端点
            response = await client.post("/api/v1/internal/srs/on_unpublish", json=payload)

            # Assert 1: 验证 API 响应是成功的
            assert response.status_code == 200
            assert response.json()["code"] == 0

            # Assert 2: 验证数据库状态被立即更新为 'finished'
            # 因为不再有异步任务的干扰，我们可以安全地使用测试会话db来验证
            await db.refresh(live_session)
            assert live_session.status == LiveSessionStatus.FINISHED
            assert live_session.end_time is not None

            # Assert 3: 验证后台任务被准确地调用了一次，并且传递了正确的session_id
            mock_task_delay.assert_called_once_with(str(original_session_id))