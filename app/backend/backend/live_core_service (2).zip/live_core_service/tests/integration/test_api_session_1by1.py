"""
LiveCore Service - Session API Integration Tests

This module contains integration tests for the session API endpoints,
testing the external API contract and critical business logic flows.
"""

import pytest
import uuid
import json
from datetime import datetime, timezone
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.live_core import LiveRoom, LiveSession, SessionStatistics, LiveSessionStatus
from app.schemas.live_core import LiveSessionCreate


# Helper function to create a test room via API
async def create_test_room_via_api(client: AsyncClient, auth_headers: dict) -> dict:
    """通过API创建测试房间并返回响应数据"""
    room_data = {
        "title": "测试房间",
        "description": "API测试房间",
        "is_private": False,
        "record_by_default": True
    }
    
    response = await client.post("/api/v1/rooms", json=room_data, headers=auth_headers)
    assert response.status_code == 200
    
    response_json = response.json()
    assert response_json["code"] == 200
    return response_json["data"]


# Helper function to create a test room directly in database
async def create_test_room_in_db(db: AsyncSession, user_id: uuid.UUID = None) -> LiveRoom:
    """直接在数据库中创建测试房间"""
    # 如果没有提供user_id，使用默认的测试用户ID
    if user_id is None:
        user_id = uuid.UUID("1142ba9a-f551-4a86-9a0e-a281c93ca36a")  # 使用测试用户ID

    room = LiveRoom(
        title="数据库测试房间",
        description="用于API测试的房间",
        stream_key=f"test_key_{uuid.uuid4().hex[:8]}",
        is_private=False,
        record_by_default=True,
        user_id=user_id  # 添加user_id字段
    )
    db.add(room)
    await db.commit()
    await db.refresh(room)
    return room


@pytest.mark.asyncio
async def test_delete_finished_session_success(async_client, db_session, auth_headers, test_user_id):
    """
    测试成功删除已结束的场次
    - 流程：创建已结束的场次然后删除
    - 验证：API响应正确，数据库中的记录被删除
    """
    async for client in async_client:
        async for db in db_session:
            # Arrange: 在数据库中创建房间和已结束的会话
            room = await create_test_room_in_db(db, user_id=test_user_id)

            session = LiveSession(
                room_id=room.id,
                status=LiveSessionStatus.FINISHED,
                start_time=datetime.now(timezone.utc),
                end_time=datetime.now(timezone.utc),
                video_id=None
            )
            db.add(session)
            await db.commit()
            await db.refresh(session)
            session_id = session.id

            # Act: 删除已结束的场次
            response = await client.delete(f"/api/v1/sessions/{session_id}", headers=auth_headers)

            # Assert API Response: 验证API响应
            assert response.status_code == 200
            response_json = response.json()
            assert response_json["code"] == 200
            assert response_json["message"] == "success"
            assert response_json["data"]["id"] == str(session_id)
            assert response_json["data"]["status"] == "deleted"

            # Verify Database State: 验证记录被删除
            deleted_session_result = await db.execute(
                select(LiveSession).where(LiveSession.id == session_id)
            )
            deleted_session = deleted_session_result.scalar_one_or_none()

            # Assert: 验证行被真正删除
            assert deleted_session is None


