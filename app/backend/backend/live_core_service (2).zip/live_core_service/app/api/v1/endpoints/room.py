"""
LiveCore Service - Room API Endpoints

This module contains all API endpoints for LiveRoom resource,
providing REST API interface for room operations.
"""

import uuid
import logging
from typing import Any, Dict

from fastapi import APIRouter, Depends, Query, File, UploadFile, HTTPException, Request
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.core.deps import get_current_user
from app.schemas.live_core import LiveRoomCreate, LiveRoomUpdate, LiveRoomResponse, ScheduledSessionCreate, LiveSessionCreate
from app.services.room_service import RoomService
from app.services.session_service import SessionService
from app.models.live_core import LiveSessionStatus
from app.crud import room as crud_room
from app.exceptions import (
    RoomNotFoundException,
    ActionForbiddenException,
    ParentRoomNotFoundException
)
from app.core.responses import success_response, error_response

# 设置日志
logger = logging.getLogger(__name__)

# 创建路由器
router = APIRouter()


@router.post("", response_model=Dict[str, Any])
async def create_room(
    room_in: LiveRoomCreate,
    current_user: dict = Depends(get_current_user),  # 新增认证参数
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """创建直播房间"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理创建房间请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = RoomService(db=db)
    
    try:
        # 调用服务层创建房间
        new_room = await service.create_new_room(room_in=room_in, user_id=uuid.UUID(current_user["user_id"]))
        logger.info(f"成功创建直播房间: {new_room.id}")
        
        # 构建响应数据
        response_data = {
            "id": str(new_room.id),
            "title": new_room.title,
            "description": new_room.description,
            "stream_key": new_room.stream_key,
            "record_by_default": new_room.record_by_default,
            "created_at": new_room.created_at.isoformat() + "Z"
        }
        
        return success_response(data=response_data)
        
    except ParentRoomNotFoundException:
        logger.warning(f"主会场不存在: {room_in.parent_room_id}")
        return JSONResponse(
            status_code=400,
            content=error_response(
                code=2004,
                message="主会场不存在",
                data={"parent_room_id": str(room_in.parent_room_id)}
            )
        )


@router.get("", response_model=Dict[str, Any])
async def get_rooms(
    request: Request, # 2. 将 Request 对象注入到你的端点中
    page: int = Query(1, ge=1, description="页码"),
    size: int = Query(10, ge=1, le=100, description="每页大小"),
    user_id: str = Query(None, description="可选的用户ID过滤"),
    current_user: dict = Depends(get_current_user),  # 新增认证参数

    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """获取直播房间列表"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理获取房间列表请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = RoomService(db=db)
    
    # 调用服务层获取房间列表
    filter_user_id = uuid.UUID(user_id) if user_id else None
    rooms, total = await service.get_room_list(page=page, size=size, user_id=filter_user_id)
    
    # 构建响应数据
    items = []
    base_url = str(request.base_url) # -> "http://localhost:8000/" 或 "https://yourdomain.com/"
    # 如果 base_url 结尾有斜杠，可以去掉
    if base_url.endswith('/'):
        base_url = base_url[:-1]

    for room in rooms:
        # 【关键修改】在这里进行URL拼接
        full_cover_url = None
        if room.cover_url:
            relative_url = room.cover_url if room.cover_url.startswith('/') else f'/{room.cover_url}'
            full_cover_url = f"{base_url}{relative_url}"

        item = {
            "id": str(room.id),
            "title": room.title,
            "cover_url": full_cover_url,
            "parent_room_id": str(room.parent_room_id) if room.parent_room_id is not None else None,
            "created_at": room.created_at.isoformat() + "Z"
        }
        items.append(item)
    
    paginated_data = {
        "total": total,
        "page": page,
        "size": size,
        "items": items
    }
    
    logger.info(f"成功获取房间列表: 总数={total}, 当前页={page}")
    
    return success_response(data=paginated_data)


@router.get("/{room_id}", response_model=Dict[str, Any])
async def get_room(
    room_id: uuid.UUID,
    user_id: str = Query(None, description="可选的用户ID过滤"),
    current_user: dict = Depends(get_current_user),  # 新增认证参数
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """获取单个直播房间详情"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理获取房间详情请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = RoomService(db=db)
    
    try:
        # 调用服务层获取房间详情
        filter_user_id = uuid.UUID(user_id) if user_id else None
        room = await service.get_room_details(room_id=room_id, user_id=filter_user_id)
        logger.info(f"成功获取房间详情: {room_id}")
        
        # 构建响应数据
        response_data = {
            "id": str(room.id),
            "title": room.title,
            "description": room.description,
            "cover_url": room.cover_url,
            "stream_key": room.stream_key,
            "parent_room_id": str(room.parent_room_id) if room.parent_room_id is not None else None,
            "is_private": room.is_private,
            "record_by_default": room.record_by_default,
            "created_at": room.created_at.isoformat() + "Z"
        }
        
        return success_response(data=response_data)
        
    except RoomNotFoundException:
        logger.warning(f"房间不存在: {room_id}")
        return JSONResponse(
            status_code=404,
            content=error_response(
                code=2001,
                message="资源不存在",
                data={"resource": "Room", "id": str(room_id)}
            )
        )


@router.patch("/{room_id}", response_model=Dict[str, Any])
async def update_room(
    room_id: uuid.UUID,
    room_update: LiveRoomUpdate,
    current_user: dict = Depends(get_current_user),  # 新增认证参数
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """更新直播房间信息"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理更新房间请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = RoomService(db=db)
    
    try:
        # 调用服务层更新房间
        updated_room = await service.update_room_info(
            room_id=room_id, 
            room_update=room_update,
            user_id=uuid.UUID(current_user["user_id"])
        )
        logger.info(f"成功更新房间信息: {room_id}")
        
        # 构建响应数据
        response_data = {
            "id": str(updated_room.id),
            "title": updated_room.title,
            "description": updated_room.description,
            "updated_at": updated_room.updated_at.isoformat() + "Z"
        }
        
        return success_response(data=response_data)
        
    except RoomNotFoundException:
        logger.warning(f"房间不存在: {room_id}")
        return JSONResponse(
            status_code=404,
            content=error_response(
                code=2001,
                message="资源不存在",
                data={"resource": "Room", "id": str(room_id)}
            )
        )
    except ActionForbiddenException as e:
        logger.warning(f"房间正在直播，无法修改: {room_id}")
        return JSONResponse(
            status_code=403,
            content=error_response(
                code=2002,
                message="业务逻辑错误",
                data={"error": str(e)}
            )
        )


@router.delete("/{room_id}", response_model=Dict[str, Any])
async def delete_room(
    room_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),  # 新增认证参数
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """删除直播房间"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理删除房间请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = RoomService(db=db)
    
    try:
        # 调用服务层删除房间
        deleted_room = await service.delete_room(room_id=room_id, user_id=uuid.UUID(current_user["user_id"]))
        logger.info(f"成功删除房间: {room_id}")
        
        # 构建响应数据
        response_data = {
            "id": str(deleted_room.id),
            "status": "deleted"
        }
        
        return success_response(data=response_data)
        
    except RoomNotFoundException:
        logger.warning(f"房间不存在: {room_id}")
        return JSONResponse(
            status_code=404,
            content=error_response(
                code=2001,
                message="资源不存在",
                data={"resource": "Room", "id": str(room_id)}
            )
        )
    except ActionForbiddenException as e:
        logger.warning(f"房间正在直播，无法删除: {room_id}")
        return JSONResponse(
            status_code=403,
            content=error_response(
                code=2003,
                message="业务逻辑错误",
                data={"error": str(e)}
            )
        )


@router.get("/{room_id}/sub-venues", response_model=Dict[str, Any])
async def get_sub_venues(
    room_id: uuid.UUID,
    page: int = Query(1, ge=1, description="页码"),
    size: int = Query(10, ge=1, le=100, description="每页大小"),
    user_id: str = Query(None, description="可选的用户ID过滤"),
    current_user: dict = Depends(get_current_user),  # 新增认证参数
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """获取分会场列表"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理获取分会场列表请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = RoomService(db=db)
    
    try:
        # 调用服务层获取分会场列表
        filter_user_id = uuid.UUID(user_id) if user_id else None
        sub_venues, total = await service.get_sub_venue_list(
            parent_room_id=room_id,
            page=page,
            size=size,
            user_id=filter_user_id
        )
        
        # 构建响应数据
        items = []
        for venue in sub_venues:
            item = {
                "id": str(venue['id']),
                "title": venue['title'],
                "live_status": venue['live_status'],
                "current_session_id": str(venue['current_session_id']) if venue['current_session_id'] else None
            }
            items.append(item)
        
        paginated_data = {
            "total": total,
            "page": page,
            "size": size,
            "items": items
        }
        
        logger.info(f"成功获取分会场列表: 总数={total}, 当前页={page}")
        
        return success_response(data=paginated_data)
        
    except RoomNotFoundException:
        logger.warning(f"主会场不存在: {room_id}")
        return JSONResponse(
            status_code=404,
            content=error_response(
                code=2001,
                message="资源不存在",
                data={"resource": "Room", "id": str(room_id)}
            )
        )


@router.post("/{room_id}/sessions", response_model=Dict[str, Any])
async def create_scheduled_session(
    room_id: uuid.UUID,
    scheduled_session_in: ScheduledSessionCreate,
    current_user: dict = Depends(get_current_user),  # 新增认证参数
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """为指定房间创建一个计划中的直播场次"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理创建计划场次请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = SessionService(db=db)
    
    try:
        # 调用服务层创建计划场次
        new_session = await service.create_scheduled_session(
            room_id=room_id,
            session_in=scheduled_session_in,
            user_id=uuid.UUID(current_user["user_id"])
        )
        logger.info(f"成功创建计划场次: session_id={new_session.id}")
        
        # 构建响应数据
        response_data = {
            "id": str(new_session.id),
            "room_id": str(new_session.room_id),
            "status": new_session.status.value,
            "start_time": new_session.start_time.isoformat() + "Z",
            "end_time": None,
            "video_id": None,
            "created_at": new_session.created_at.isoformat() + "Z",
            "updated_at": new_session.updated_at.isoformat() + "Z"
        }
        
        return success_response(data=response_data)
        
    except RoomNotFoundException:
        logger.warning(f"房间不存在: room_id={room_id}")
        return JSONResponse(
            status_code=404,
            content=error_response(
                code=2001,
                message="资源不存在",
                data={"resource": "Room", "id": str(room_id)}
            )
        )


@router.get("/{room_id}/sessions", response_model=Dict[str, Any])
async def get_room_sessions(
    room_id: uuid.UUID,
    page: int = Query(1, ge=1, description="页码"),
    size: int = Query(10, ge=1, le=100, description="每页大小"),
    user_id: str = Query(None, description="可选的用户ID过滤"),
    current_user: dict = Depends(get_current_user),  # 新增认证参数
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """获取指定房间的直播场次列表"""
    # 在业务逻辑开始前记录日志
    logger.info(f"开始处理获取房间场次列表请求: user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = SessionService(db=db)
    
    try:
        # 调用服务层获取场次列表
        filter_user_id = uuid.UUID(user_id) if user_id else None
        sessions, total = await service.get_sessions_by_room(
            room_id=room_id,
            page=page,
            size=size,
            user_id=filter_user_id
        )
        
        # 构建响应数据
        items = []
        for session in sessions:
            item = {
                "id": str(session.id),
                "room_id": str(session.room_id),
                "status": session.status.value,
                "start_time": session.start_time.isoformat() + "Z",
                "end_time": session.end_time.isoformat() + "Z" if session.end_time else None,
                "video_id": str(session.video_id) if session.video_id else None,
                "created_at": session.created_at.isoformat() + "Z",
                "updated_at": session.updated_at.isoformat() + "Z"
            }
            items.append(item)
        
        paginated_data = {
            "total": total,
            "page": page,
            "size": len(items),
            "items": items
        }
        
        logger.info(f"成功获取房间场次列表: room_id={room_id}, 返回{len(items)}条记录")
        
        return success_response(data=paginated_data)
        
    except RoomNotFoundException:
        logger.warning(f"房间不存在: room_id={room_id}")
        return JSONResponse(
            status_code=404,
            content=error_response(
                code=2001,
                message="资源不存在",
                data={"resource": "Room", "id": str(room_id)}
            )
        )


@router.post("/{room_id}/cover", response_model=Dict[str, Any])
async def upload_room_cover(
    room_id: uuid.UUID,
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """为指定房间上传封面图片"""
    logger.info(f"开始上传封面: room_id={room_id}, user_id={current_user['user_id']}")
    
    # 实例化服务层
    service = RoomService(db=db)
    
    try:
        # 调用服务层上传封面
        updated_room = await service.upload_room_cover(
            room_id=room_id,
            file=file,
            user_id=uuid.UUID(current_user["user_id"])
        )
        
        logger.info(f"封面上传成功: room_id={room_id}")
        
        # 构建响应数据
        response_data = {
            "room_id": str(updated_room.id),
            "cover_url": updated_room.cover_url
        }
        
        return success_response(data=response_data)
        
    except RoomNotFoundException:
        logger.warning(f"房间不存在: room_id={room_id}")
        return JSONResponse(
            status_code=404,
            content=error_response(
                code=2001,
                message="资源不存在",
                data={"resource": "Room", "id": str(room_id)}
            )
        )
    except ActionForbiddenException as e:
        logger.warning(f"无权上传封面: room_id={room_id}, user_id={current_user['user_id']}")
        return JSONResponse(
            status_code=403,
            content=error_response(
                code=2003,
                message="业务逻辑错误",
                data={"error": str(e)}
            )
        )
    except HTTPException as e:
        logger.warning(f"文件验证失败: {e.detail}")
        return JSONResponse(
            status_code=e.status_code,
            content=error_response(
                code=2001,
                message="文件验证失败",
                data={"error": e.detail}
            )
        )
    except Exception as e:
        logger.error(f"封面上传失败: {str(e)}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content=error_response(
                code=5001,
                message="文件上传失败",
                data={"error": "服务器内部错误"}
            )
        ) 