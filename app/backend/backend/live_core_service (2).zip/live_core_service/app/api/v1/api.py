"""
LiveCore Service - API Router

聚合所有v1版本的API路由
"""

from fastapi import APIRouter

from app.api.v1.endpoints import room, session

from app.api.v1.endpoints import internal

api_router = APIRouter()

# 注册各个模块的路由
api_router.include_router(room.router, prefix="/rooms", tags=["rooms"])
api_router.include_router(session.router, prefix="", tags=["sessions"])

# --- 新增：注册新的内部回调API路由 ---
# 我们为它指定一个清晰、隔离的路径前缀
api_router.include_router(
    internal.router,
    prefix="/internal/srs",
    tags=["Internal SRS Callbacks"]
)