"""
LiveCore Service - Custom Business Exceptions

This module contains all custom exceptions for the LiveCore Service,
used for business logic validation and error handling.
"""


class RoomNotFoundException(Exception):
    """Raised when a room is not found in the database."""
    pass


class ActionForbiddenException(Exception):
    """Raised when an action is not permitted due to business logic."""
    
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class ParentRoomNotFoundException(Exception):
    """Raised when the specified parent room does not exist."""
    pass


class SessionNotFoundException(Exception):
    """Raised when a session is not found in the database."""
    pass


class SessionActionForbiddenException(Exception):
    """Raised when an action on a session is not permitted."""
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message) 