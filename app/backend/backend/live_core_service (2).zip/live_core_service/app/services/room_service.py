"""
LiveCore Service - Room Service

This module contains the business logic layer for LiveRoom operations,
implementing all business rules and validation logic.
"""

import uuid
import logging
from typing import List, Tuple, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import UploadFile

from app.crud import room as crud_room
from app.schemas.live_core import LiveRoomCreate, LiveRoomUpdate
from app.models.live_core import LiveRoom
from app.core.file_handler import FileHandler
from app.exceptions import (
    RoomNotFoundException,
    ActionForbiddenException,
    ParentRoomNotFoundException
)

# 设置日志
logger = logging.getLogger(__name__)


class RoomService:
    """
    房间业务逻辑服务类
    
    封装所有与LiveRoom相关的业务逻辑，包括业务规则验证、
    数据一致性检查等。该层不应了解HTTP请求/响应相关的内容。
    """
    
    def __init__(self, db: AsyncSession):
        """
        初始化房间服务
        
        Args:
            db: 异步数据库会话
        """
        self.db = db

    async def create_new_room(self, room_in: LiveRoomCreate, user_id: uuid.UUID) -> LiveRoom:
        """
        创建新的直播房间
        
        业务逻辑流程:
        1. 如果指定了parent_room_id，检查父房间是否存在
        2. 如果父房间不存在，抛出ParentRoomNotFoundException
        3. 调用CRUD层创建新房间
        
        Args:
            room_in: 房间创建请求数据
            user_id: 用户ID
            
        Returns:
            创建的房间对象
            
        Raises:
            ParentRoomNotFoundException: 当指定的父房间不存在时
        """
        logger.info(f"开始创建新房间: user_id={user_id}, title={room_in.title}")
        
        try:
            # 如果指定了父房间ID，检查父房间是否存在
            if room_in.parent_room_id:
                logger.info(f"检查父房间是否存在: parent_room_id={room_in.parent_room_id}")
                parent_room = await crud_room.get(db=self.db, room_id=room_in.parent_room_id)
                if not parent_room:
                    logger.warning(f"父房间不存在: parent_room_id={room_in.parent_room_id}")
                    raise ParentRoomNotFoundException()
                logger.info(f"父房间验证通过: parent_room_id={room_in.parent_room_id}")
            
            # 创建新房间
            room = await crud_room.create(db=self.db, obj_in=room_in, user_id=user_id)
            logger.info(f"成功创建新房间: room_id={room.id}, title={room.title}")
            return room
            
        except ParentRoomNotFoundException:
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"创建房间失败: user_id={user_id}, title={room_in.title}, error={str(e)}", exc_info=True)
            raise

    async def get_room_list(self, page: int, size: int, user_id: Optional[uuid.UUID] = None) -> Tuple[List[LiveRoom], int]:
        """
        获取房间列表
        
        业务逻辑流程:
        1. 计算skip值
        2. 调用CRUD层获取分页数据
        
        Args:
            page: 页码
            size: 每页大小
            user_id: 可选的用户ID，用于过滤
            
        Returns:
            房间列表和总数的元组
        """
        logger.info(f"开始获取房间列表: page={page}, size={size}, user_id={user_id}")
        
        try:
            # 计算skip值
            skip = (page - 1) * size
            
            # 调用CRUD层获取房间列表和总数
            rooms, total = await crud_room.get_multi_and_total(
                db=self.db, skip=skip, limit=size, user_id=user_id
            )
            
            logger.info(f"成功获取房间列表: 返回{len(rooms)}条记录, 总数={total}")
            return rooms, total
            
        except Exception as e:
            logger.error(f"获取房间列表失败: page={page}, size={size}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise

    async def get_room_details(self, room_id: uuid.UUID, user_id: Optional[uuid.UUID] = None) -> LiveRoom:
        """
        获取房间详情
        
        业务逻辑流程:
        1. 调用CRUD层获取房间
        2. 如果房间不存在，抛出RoomNotFoundException
        
        Args:
            room_id: 房间ID
            user_id: 可选的用户ID，用于权限验证
            
        Returns:
            房间对象
            
        Raises:
            RoomNotFoundException: 当房间不存在时
        """
        logger.info(f"开始获取房间详情: room_id={room_id}, user_id={user_id}")
        
        try:
            room = await crud_room.get(db=self.db, room_id=room_id, user_id=user_id)
            if not room:
                logger.warning(f"房间不存在: room_id={room_id}, user_id={user_id}")
                raise RoomNotFoundException()
            
            logger.info(f"成功获取房间详情: room_id={room_id}, title={room.title}")
            return room
            
        except RoomNotFoundException:
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"获取房间详情失败: room_id={room_id}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise

    async def update_room_info(self, room_id: uuid.UUID, room_update: LiveRoomUpdate, user_id: uuid.UUID) -> LiveRoom:
        """
        更新房间信息
        
        业务逻辑流程:
        1. 获取房间对象（包含存在性检查）
        2. 检查房间是否正在直播
        3. 如果正在直播，抛出ActionForbiddenException
        4. 调用CRUD层执行更新
        
        Args:
            room_id: 房间ID
            room_update: 更新数据
            user_id: 用户ID
            
        Returns:
            更新后的房间对象
            
        Raises:
            RoomNotFoundException: 当房间不存在时
            ActionForbiddenException: 当房间正在直播时
        """
        logger.info(f"开始更新房间信息: room_id={room_id}, user_id={user_id}")
        
        try:
            # 获取房间对象（此步骤已包含"不存在"的检查）
            room = await self.get_room_details(room_id, user_id=user_id)
            
            # 检查房间是否正在直播
            logger.info(f"检查房间直播状态: room_id={room_id}")
            is_live = await crud_room.is_live(db=self.db, room_id=room_id)
            if is_live:
                logger.warning(f"房间正在直播，无法修改: room_id={room_id}")
                raise ActionForbiddenException("无法修改正在直播的房间")
            
            # 执行更新
            updated_room = await crud_room.update(db=self.db, db_obj=room, obj_in=room_update)
            logger.info(f"成功更新房间信息: room_id={room_id}, title={updated_room.title}")
            return updated_room
            
        except (RoomNotFoundException, ActionForbiddenException):
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"更新房间信息失败: room_id={room_id}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise

    async def delete_room(self, room_id: uuid.UUID, user_id: uuid.UUID) -> LiveRoom:
        """
        删除房间
        
        业务逻辑流程:
        1. 获取房间对象（包含存在性检查）
        2. 检查房间是否正在直播
        3. 如果正在直播，抛出ActionForbiddenException
        4. 调用CRUD层执行删除
        
        Args:
            room_id: 房间ID
            user_id: 用户ID
            
        Returns:
            被删除的房间对象
            
        Raises:
            RoomNotFoundException: 当房间不存在时
            ActionForbiddenException: 当房间正在直播时
        """
        logger.info(f"开始删除房间: room_id={room_id}, user_id={user_id}")
        
        try:
            # 获取房间对象
            room = await self.get_room_details(room_id, user_id=user_id)
            
            # 检查房间是否正在直播
            logger.info(f"检查房间直播状态: room_id={room_id}")
            is_live = await crud_room.is_live(db=self.db, room_id=room_id)
            if is_live:
                logger.warning(f"房间正在直播，无法删除: room_id={room_id}")
                raise ActionForbiddenException("无法删除正在直播的房间")
            
            # 执行删除
            deleted_room = await crud_room.remove(db=self.db, db_obj=room)
            logger.info(f"成功删除房间: room_id={room_id}, title={deleted_room.title}")
            return deleted_room
            
        except (RoomNotFoundException, ActionForbiddenException):
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"删除房间失败: room_id={room_id}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise

    async def get_sub_venue_list(
        self, 
        parent_room_id: uuid.UUID, 
        page: int, 
        size: int,
        user_id: Optional[uuid.UUID] = None
    ) -> Tuple[List[Dict[str, Any]], int]:
        """
        获取分会场列表
        
        业务逻辑流程:
        1. 检查主会场是否存在
        2. 计算skip值
        3. 调用CRUD层获取分会场列表
        
        Args:
            parent_room_id: 主会场ID
            page: 页码
            size: 每页大小
            user_id: 可选的用户ID，用于权限验证
            
        Returns:
            分会场列表和总数的元组
            
        Raises:
            RoomNotFoundException: 当主会场不存在时
        """
        logger.info(f"开始获取分会场列表: parent_room_id={parent_room_id}, page={page}, size={size}, user_id={user_id}")
        
        try:
            # 检查主会场是否存在（如果提供user_id则验证权限）
            if user_id:
                await self.get_room_details(parent_room_id, user_id=user_id)
            else:
                await self.get_room_details(parent_room_id)
            
            # 计算skip值
            skip = (page - 1) * size
            
            # 获取分会场列表和总数
            sub_venues, total = await crud_room.get_sub_venues_with_live_status(
                db=self.db, parent_room_id=parent_room_id, skip=skip, limit=size, user_id=user_id
            )
            
            logger.info(f"成功获取分会场列表: parent_room_id={parent_room_id}, 返回{len(sub_venues)}条记录, 总数={total}")
            return sub_venues, total
            
        except RoomNotFoundException:
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"获取分会场列表失败: parent_room_id={parent_room_id}, page={page}, size={size}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise

    async def upload_room_cover(
        self, 
        room_id: uuid.UUID, 
        file: UploadFile,
        user_id: uuid.UUID
    ) -> LiveRoom:
        """
        为指定房间上传封面图片
        
        Args:
            room_id: 房间ID
            file: 上传的文件对象
            user_id: 当前用户ID
            
        Returns:
            更新后的LiveRoom对象
            
        Raises:
            RoomNotFoundException: 房间不存在
            ActionForbiddenException: 用户无权修改此房间
        """
        logger.info(f"开始上传房间封面: room_id={room_id}, user_id={user_id}")
        
        try:
            # 1. 验证房间存在性和用户权限
            room = await self.get_room_details(room_id=room_id, user_id=user_id)
            
            # 2. 如果房间已有封面，删除旧文件
            if room.cover_url:
                logger.info(f"删除旧封面文件: cover_url={room.cover_url}")
                FileHandler.delete_old_cover(room.cover_url)
            
            # 3. 保存新文件
            cover_url = await FileHandler.save_cover_file(file=file, room_id=room_id)
            logger.info(f"新封面文件保存成功: cover_url={cover_url}")
            
            # 4. 更新数据库 cover_url
            updated_room = await crud_room.update_cover_url(
                db=self.db, 
                room_id=room_id, 
                cover_url=cover_url
            )
            
            if not updated_room:
                logger.error(f"更新封面URL失败: room_id={room_id}")
                raise Exception("更新封面URL失败")
            
            logger.info(f"封面上传成功: room_id={room_id}, cover_url={cover_url}")
            
            # 5. 返回更新后的房间对象
            return updated_room
            
        except (RoomNotFoundException, ActionForbiddenException):
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"上传房间封面失败: room_id={room_id}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise 