"""
LiveCore Service - Session Business Logic Service

This module contains the SessionService class that encapsulates all business logic
related to LiveSession operations, providing a clean separation between
HTTP endpoints and data access layers.
"""

import uuid
import logging
from typing import List, Tuple, Optional
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.live_core import LiveSession, LiveSessionStatus
from app.schemas.live_core import ScheduledSessionCreate, LiveSessionCreate, LiveSessionUpdate
from app.crud import session as crud_session, room as crud_room
from app.exceptions import (
    SessionNotFoundException,
    SessionActionForbiddenException,
    RoomNotFoundException
)

# 设置日志
logger = logging.getLogger(__name__)


class SessionService:
    """
    Session业务逻辑服务类
    
    负责处理所有与LiveSession相关的业务逻辑，包括：
    - 创建计划场次
    - 获取场次详情和列表
    - 更新场次信息
    - 删除场次
    
    该服务层保持框架无关性，不包含HTTP相关的逻辑。
    """
    
    def __init__(self, db: AsyncSession):
        """
        初始化SessionService
        
        Args:
            db: 异步数据库会话
        """
        self.db = db
    
    async def create_scheduled_session(
        self, 
        room_id: uuid.UUID, 
        session_in: ScheduledSessionCreate,
        user_id: uuid.UUID
    ) -> LiveSession:
        """
        为指定房间创建一个计划中的直播场次
        
        Args:
            room_id: 房间ID
            session_in: 计划场次创建数据
            user_id: 用户ID
            
        Returns:
            创建的LiveSession对象
            
        Raises:
            RoomNotFoundException: 当房间不存在时
        """
        logger.info(f"开始创建计划场次: room_id={room_id}, user_id={user_id}, start_time={session_in.start_time}")
        
        try:
            # 1. 验证房间是否存在且属于当前用户
            room = await crud_room.get(db=self.db, room_id=room_id, user_id=user_id)
            if room is None:
                logger.warning(f"房间不存在或无权限: room_id={room_id}, user_id={user_id}")
                raise RoomNotFoundException()
            
            # 2. 创建LiveSessionCreate对象
            session_create = LiveSessionCreate(
                room_id=room_id,
                status=LiveSessionStatus.SCHEDULED,
                start_time=session_in.start_time,
                end_time=None,
                video_id=None
            )
            
            # 3. 调用CRUD层创建会话和统计信息
            new_session = await crud_session.create_with_stats(db=self.db, obj_in=session_create)
            
            logger.info(f"成功创建计划场次: session_id={new_session.id}, room_id={room_id}")
            return new_session
            
        except RoomNotFoundException:
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"创建计划场次失败: room_id={room_id}, user_id={user_id}, start_time={session_in.start_time}, error={str(e)}", exc_info=True)
            raise
    
    async def get_sessions_by_room(
        self, 
        room_id: uuid.UUID, 
        page: int, 
        size: int,
        user_id: Optional[uuid.UUID] = None
    ) -> Tuple[List[LiveSession], int]:
        """
        获取指定房间的直播场次列表
        
        Args:
            room_id: 房间ID
            page: 页码
            size: 每页大小
            user_id: 可选的用户ID，用于权限验证
            
        Returns:
            (会话列表, 总数)的元组
            
        Raises:
            RoomNotFoundException: 当房间不存在时
        """
        logger.info(f"开始获取房间场次列表: room_id={room_id}, page={page}, size={size}, user_id={user_id}")
        
        try:
            # 1. 验证房间是否存在（如果提供user_id则验证权限）
            if user_id:
                room = await crud_room.get(db=self.db, room_id=room_id, user_id=user_id)
            else:
                room = await crud_room.get(db=self.db, room_id=room_id)
            if room is None:
                logger.warning(f"房间不存在: room_id={room_id}, user_id={user_id}")
                raise RoomNotFoundException()
            
            # 2. 计算skip值
            skip = (page - 1) * size
            
            # 3. 调用CRUD层获取场次列表和总数
            sessions, total = await crud_session.get_multi_by_room_and_total(
                db=self.db,
                room_id=room_id,
                skip=skip,
                limit=size,
                user_id=user_id
            )
            
            logger.info(f"成功获取房间场次列表: room_id={room_id}, 返回{len(sessions)}条记录, 总数={total}")
            return sessions, total
            
        except RoomNotFoundException:
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"获取房间场次列表失败: room_id={room_id}, page={page}, size={size}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise
    
    async def get_session_details(self, session_id: uuid.UUID, user_id: Optional[uuid.UUID] = None) -> LiveSession:
        """
        获取单场直播的详细信息（包含统计信息）
        
        Args:
            session_id: 会话ID
            user_id: 可选的用户ID，用于权限验证
            
        Returns:
            包含统计信息的LiveSession对象
            
        Raises:
            SessionNotFoundException: 当会话不存在时
        """
        logger.info(f"开始获取直播会话详情: session_id={session_id}, user_id={user_id}")
        
        try:
            # 1. 如果提供user_id，先验证权限
            if user_id:
                session = await crud_session.get(db=self.db, session_id=session_id, user_id=user_id)
                if not session:
                    logger.warning(f"直播会话不存在或无权限: session_id={session_id}, user_id={user_id}")
                    raise SessionNotFoundException()
                # 重新获取包含统计信息的会话
                session = await crud_session.get_with_stats(db=self.db, session_id=session_id)
            else:
                # 2. 调用CRUD层获取会话和统计信息
                session = await crud_session.get_with_stats(db=self.db, session_id=session_id)
            
            # 3. 检查会话是否存在
            if session is None:
                logger.warning(f"直播会话不存在: session_id={session_id}")
                raise SessionNotFoundException()
            
            logger.info(f"成功获取直播会话详情: session_id={session_id}, room_id={session.room_id}")
            return session
            
        except SessionNotFoundException:
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"获取直播会话详情失败: session_id={session_id}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise
    
    async def update_scheduled_session_info(
        self, 
        session_id: uuid.UUID, 
        session_update: LiveSessionUpdate,
        user_id: uuid.UUID
    ) -> LiveSession:
        """
        更新计划场次的信息
        
        Args:
            session_id: 会话ID
            session_update: 更新数据
            user_id: 用户ID
            
        Returns:
            更新后的LiveSession对象
            
        Raises:
            SessionNotFoundException: 当会话不存在时
            SessionActionForbiddenException: 当会话状态不允许修改时
        """
        logger.info(f"开始更新计划场次: session_id={session_id}, user_id={user_id}")
        
        try:
            # 1. 获取会话对象并验证权限
            session = await crud_session.get(db=self.db, session_id=session_id, user_id=user_id)
            if session is None:
                logger.warning(f"直播会话不存在或无权限: session_id={session_id}, user_id={user_id}")
                raise SessionNotFoundException()
            
            # 2. 业务逻辑检查：只能修改计划中的场次
            if session.status != LiveSessionStatus.SCHEDULED:
                logger.warning(f"无法修改非计划状态的场次: session_id={session_id}, status={session.status}")
                raise SessionActionForbiddenException("无法修改正在直播或已结束场次的计划开始时间")
            
            # 3. 调用CRUD层更新
            updated_session = await crud_session.update(db=self.db, db_obj=session, obj_in=session_update)
            
            logger.info(f"成功更新计划场次: session_id={session_id}, room_id={updated_session.room_id}")
            return updated_session
            
        except (SessionNotFoundException, SessionActionForbiddenException):
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"更新计划场次失败: session_id={session_id}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise
    
    async def delete_session(self, session_id: uuid.UUID, user_id: uuid.UUID) -> LiveSession:
        """
        删除指定的直播场次
        
        Args:
            session_id: 会话ID
            user_id: 用户ID
            
        Returns:
            被删除的LiveSession对象
            
        Raises:
            SessionNotFoundException: 当会话不存在时
            SessionActionForbiddenException: 当会话正在直播时
        """
        logger.info(f"开始删除计划场次: session_id={session_id}, user_id={user_id}")
        
        try:
            # 1. 获取会话对象并验证权限
            session = await crud_session.get(db=self.db, session_id=session_id, user_id=user_id)
            if session is None:
                logger.warning(f"直播会话不存在或无权限: session_id={session_id}, user_id={user_id}")
                raise SessionNotFoundException()
            
            # 2. 业务逻辑检查：不能删除正在直播的场次
            if session.status == LiveSessionStatus.LIVE:
                logger.warning(f"无法删除正在直播的场次: session_id={session_id}, status={session.status}")
                raise SessionActionForbiddenException("无法删除正在直播的场次")
            
            # 3. 调用CRUD层删除
            deleted_session = await crud_session.remove(db=self.db, db_obj=session)
            
            logger.info(f"成功删除计划场次: session_id={session_id}, room_id={deleted_session.room_id}")
            return deleted_session
            
        except (SessionNotFoundException, SessionActionForbiddenException):
            # 重新抛出业务异常，不记录额外日志
            raise
        except Exception as e:
            logger.error(f"删除计划场次失败: session_id={session_id}, user_id={user_id}, error={str(e)}", exc_info=True)
            raise 