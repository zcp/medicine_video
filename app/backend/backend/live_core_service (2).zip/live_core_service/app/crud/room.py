"""
LiveCore Service - Room CRUD Operations

This module contains all CRUD operations for LiveRoom model,
providing data access layer functionality.
"""
import logging
import secrets
import uuid
from typing import Optional, List, Tuple, Dict, Any
from sqlalchemy import select, func, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.live_core import LiveRoom, LiveSession, LiveSessionStatus
from app.schemas.live_core import LiveRoomCreate, LiveRoomUpdate

# 设置日志
logger = logging.getLogger(__name__)

async def get(db: AsyncSession, room_id: uuid.UUID, user_id: Optional[uuid.UUID] = None) -> Optional[LiveRoom]:
    """根据ID获取单个房间"""
    logger.debug(f"查询房间: room_id={room_id}, user_id={user_id}")
    
    try:
        query = select(LiveRoom).where(LiveRoom.id == room_id)
        if user_id:
            query = query.where(LiveRoom.user_id == user_id)
        
        result = await db.execute(query)
        room = result.scalar_one_or_none()
        
        if room:
            logger.debug(f"找到房间: room_id={room_id}, title={room.title}")
        else:
            logger.debug(f"房间不存在: room_id={room_id}")
        
        return room
        
    except Exception as e:
        logger.error(f"查询房间失败: room_id={room_id}, user_id={user_id}, error={str(e)}", exc_info=True)
        raise


async def get_by_stream_key(db: AsyncSession, stream_key: str) -> Optional[LiveRoom]:
    """根据 stream_key 获取单个房间"""
    logger.debug(f"根据stream_key查询房间: stream_key={stream_key}")
    
    try:
        result = await db.execute(
            select(LiveRoom).where(LiveRoom.stream_key == stream_key)
        )
        room = result.scalar_one_or_none()
        
        if room:
            logger.debug(f"找到房间: stream_key={stream_key}, room_id={room.id}")
        else:
            logger.debug(f"房间不存在: stream_key={stream_key}")
        
        return room
        
    except Exception as e:
        logger.error(f"根据stream_key查询房间失败: stream_key={stream_key}, error={str(e)}", exc_info=True)
        raise


async def get_multi_and_total(
    db: AsyncSession, 
    skip: int = 0, 
    limit: int = 10,
    user_id: Optional[uuid.UUID] = None
) -> Tuple[List[LiveRoom], int]:
    """分页获取房间列表，同时返回总数"""
    logger.debug(f"分页查询房间列表: skip={skip}, limit={limit}, user_id={user_id}")
    
    try:
        # 构建基础查询
        query = select(LiveRoom)
        if user_id:
            query = query.where(LiveRoom.user_id == user_id)
        
        # 获取总数
        count_query = select(func.count(LiveRoom.id))
        if user_id:
            count_query = count_query.where(LiveRoom.user_id == user_id)
        
        count_result = await db.execute(count_query)
        total = count_result.scalar()
        
        # 获取分页数据
        result = await db.execute(
            query
            .order_by(LiveRoom.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        rooms = result.scalars().all()
        
        logger.debug(f"分页查询房间列表完成: 返回{len(rooms)}条记录, 总数={total}")
        return list(rooms), total
        
    except Exception as e:
        logger.error(f"分页查询房间列表失败: skip={skip}, limit={limit}, user_id={user_id}, error={str(e)}", exc_info=True)
        raise


async def create(db: AsyncSession, obj_in: LiveRoomCreate, user_id: uuid.UUID) -> LiveRoom:
    """创建新房间，内部生成唯一的stream_key"""
    logger.info(f"开始创建房间: title={obj_in.title}, user_id={user_id}")
    
    try:
        # 生成唯一的推流密钥
        stream_key = f"sk_live_{secrets.token_hex(16)}"
        
        # 确保stream_key唯一性
        retry_count = 0
        while retry_count < 10:  # 防止无限循环
            existing = await db.execute(
                select(LiveRoom).where(LiveRoom.stream_key == stream_key)
            )
            if existing.scalar_one_or_none() is None:
                break
            stream_key = f"sk_live_{secrets.token_hex(16)}"
            retry_count += 1
        
        if retry_count >= 10:
            logger.error(f"生成唯一stream_key失败，重试次数过多: title={obj_in.title}")
            raise Exception("无法生成唯一的推流密钥")
        
        # 创建房间对象
        db_obj = LiveRoom(
            title=obj_in.title,
            description=obj_in.description,
            cover_url=obj_in.cover_url,
            stream_key=stream_key,
            is_private=obj_in.is_private,
            record_by_default=obj_in.record_by_default,
            category_id=obj_in.category_id,
            parent_room_id=obj_in.parent_room_id,
            user_id=user_id  # 新增：设置用户ID
        )
        
        db.add(db_obj)
        await db.commit()

        await db.refresh(db_obj)
        logger.info(f"房间创建事务已提交: room_id={db_obj.id}")

        logger.info(f"房间创建成功: room_id={db_obj.id}, title={db_obj.title}, stream_key={stream_key}")

        return db_obj
        
    except Exception as e:
        logger.error(f"创建房间失败: title={obj_in.title}, user_id={user_id}, error={str(e)}", exc_info=True)
        raise


async def update(
    db: AsyncSession, 
    db_obj: LiveRoom, 
    obj_in: LiveRoomUpdate
) -> LiveRoom:
    """更新房间信息"""
    logger.info(f"开始更新房间: room_id={db_obj.id}, title={db_obj.title}")
    
    try:
        # 获取更新数据，排除None值
        update_data = obj_in.model_dump(exclude_unset=True)
        logger.debug(f"更新字段: {list(update_data.keys())}")
        
        # 更新对象属性
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        
        await db.commit()

        await db.refresh(db_obj)
        logger.info(f"房间更新事务已提交: room_id={db_obj.id}")

        logger.info(f"房间更新成功: room_id={db_obj.id}, title={db_obj.title}")
        
        return db_obj
        
    except Exception as e:
        logger.error(f"更新房间失败: room_id={db_obj.id}, error={str(e)}", exc_info=True)
        raise


async def remove(db: AsyncSession, db_obj: LiveRoom) -> LiveRoom:
    """删除房间"""
    logger.info(f"开始删除房间: room_id={db_obj.id}, title={db_obj.title}")
    
    try:
        await db.delete(db_obj)
        await db.commit()
        logger.info(f"房间删除成功: room_id={db_obj.id}, title={db_obj.title}")
        
        return db_obj
        
    except Exception as e:
        logger.error(f"删除房间失败: room_id={db_obj.id}, error={str(e)}", exc_info=True)
        raise


async def is_live(db: AsyncSession, room_id: uuid.UUID) -> bool:
    """检查指定房间当前是否有状态为'live'的LiveSession记录"""
    logger.debug(f"检查房间直播状态: room_id={room_id}")
    
    try:
        result = await db.execute(
            select(LiveSession)
            .where(
                and_(
                    LiveSession.room_id == room_id,
                    LiveSession.status == LiveSessionStatus.LIVE
                )
            )
        )
        is_live_status = result.scalar_one_or_none() is not None
        logger.debug(f"房间直播状态检查完成: room_id={room_id}, is_live={is_live_status}")
        return is_live_status
        
    except Exception as e:
        logger.error(f"检查房间直播状态失败: room_id={room_id}, error={str(e)}", exc_info=True)
        raise


async def get_sub_venues_with_live_status(
    db: AsyncSession, 
    parent_room_id: uuid.UUID, 
    skip: int = 0, 
    limit: int = 10,
    user_id: Optional[uuid.UUID] = None
) -> Tuple[List[Dict[str, Any]], int]:
    """
    获取指定主会场下的所有分会场，并包含其实时直播状态
    使用LEFT OUTER JOIN关联LiveSession表
    """
    logger.debug(f"查询分会场列表: parent_room_id={parent_room_id}, skip={skip}, limit={limit}, user_id={user_id}")
    
    try:
        # 如果提供user_id，验证主会场权限
        if user_id:
            main_room_query = select(LiveRoom).where(
                and_(LiveRoom.id == parent_room_id, LiveRoom.user_id == user_id)
            )
            main_room = await db.execute(main_room_query)
            if not main_room.scalar_one_or_none():
                # 如果主会场不属于当前用户，返回空结果
                logger.debug(f"主会场不属于当前用户: parent_room_id={parent_room_id}, user_id={user_id}")
                return [], 0
        
        # 获取总数
        count_result = await db.execute(
            select(func.count(LiveRoom.id))
            .where(LiveRoom.parent_room_id == parent_room_id)
        )
        total = count_result.scalar()
        
        # 获取分会场数据和直播状态
        result = await db.execute(
            select(
                LiveRoom.id,
                LiveRoom.title,
                LiveRoom.description,
                LiveRoom.cover_url,
                LiveRoom.is_private,
                LiveRoom.record_by_default,
                LiveRoom.category_id,
                LiveRoom.user_id,
                LiveRoom.created_at,
                LiveRoom.updated_at,
                LiveSession.status.label('live_status'),
                LiveSession.id.label('current_session_id')
            )
            .select_from(LiveRoom)
            .outerjoin(
                LiveSession,
                and_(
                    LiveSession.room_id == LiveRoom.id,
                    LiveSession.status == LiveSessionStatus.LIVE
                )
            )
            .where(LiveRoom.parent_room_id == parent_room_id)
            .order_by(LiveRoom.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        
        # 转换为字典列表
        sub_venues = []
        for row in result:
            sub_venue = {
                'id': row.id,
                'title': row.title,
                'description': row.description,
                'cover_url': row.cover_url,
                'is_private': row.is_private,
                'record_by_default': row.record_by_default,
                'category_id': row.category_id,
                'user_id': row.user_id,
                'created_at': row.created_at,
                'updated_at': row.updated_at,
                'live_status': row.live_status,
                'current_session_id': row.current_session_id
            }
            sub_venues.append(sub_venue)
        
        logger.debug(f"分会场列表查询完成: parent_room_id={parent_room_id}, 返回{len(sub_venues)}条记录, 总数={total}")
        return sub_venues, total
        
    except Exception as e:
        logger.error(f"查询分会场列表失败: parent_room_id={parent_room_id}, skip={skip}, limit={limit}, user_id={user_id}, error={str(e)}", exc_info=True)
        raise


async def update_cover_url(
    db: AsyncSession, 
    room_id: uuid.UUID, 
    cover_url: str
) -> Optional[LiveRoom]:
    """
    更新房间封面URL
    
    Args:
        db: 数据库会话
        room_id: 房间ID
        cover_url: 新的封面URL
        
    Returns:
        更新后的LiveRoom对象或None
    """
    logger.info(f"开始更新房间封面URL: room_id={room_id}")
    
    try:
        # 1. 查询房间对象
        result = await db.execute(
            select(LiveRoom).where(LiveRoom.id == room_id)
        )
        room = result.scalar_one_or_none()
        
        if room is None:
            logger.warning(f"房间不存在，无法更新封面: room_id={room_id}")
            return None
        
        # 2. 更新 cover_url 字段
        room.cover_url = cover_url
        
        # 3. 提交事务
        await db.commit()
        
        # 4. 刷新对象并返回
        await db.refresh(room)
        logger.info(f"房间封面URL更新成功: room_id={room_id}, cover_url={cover_url}")
        
        return room
        
    except Exception as e:
        logger.error(f"更新房间封面URL失败: room_id={room_id}, error={str(e)}", exc_info=True)
        raise 