"""
LiveCore Service - Application Configuration

配置管理模块
"""

import os
from typing import List, Optional


class Settings:
    """应用配置类"""
    
    # 项目基本信息
    PROJECT_NAME: str = "LiveCore Service"
    VERSION: str = "1.0.0"
    DESCRIPTION: str = "直播核心功能服务API"
    
    # API配置
    API_V1_STR: str = "/api/v1"
    
    # 数据库配置
    POSTGRES_SERVER: str = os.getenv("POSTGRES_SERVER", "localhost")
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "postgres")
    POSTGRES_PASSWORD: str = os.getenv("POSTGRES_PASSWORD", "324zq999")
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "live_core_test")
    POSTGRES_PORT: str = os.getenv("POSTGRES_PORT", "5432")

    CELERY_BROKER_URL: str = os.getenv("CELERY_BROKER_URL", "redis://redis:6379/0")
    CELERY_RESULT_BACKEND: str = os.getenv(" CELERY_RESULT_BACKEND", "redis://redis:6379/0")



    @property
    def DATABASE_URL(self) -> str:
        """异步数据库连接URL"""
        return f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    @property
    def SYNC_DATABASE_URL(self) -> str:
        """同步数据库连接URL"""
        return f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    # CORS配置
    BACKEND_CORS_ORIGINS: List[str] = ["*"]
    
    # 调试模式
    DEBUG: bool = os.getenv("DEBUG", "true").lower() == "true"
    
    # 文件上传配置
    ROOM_MEDIA_ROOT_PATH: str = os.getenv("ROOM_MEDIA_ROOT_PATH", "./media")
    UPLOAD_MAX_SIZE: int = int(os.getenv("UPLOAD_MAX_SIZE", "10485760"))
    UPLOAD_ALLOWED_EXTENSIONS: str = os.getenv("UPLOAD_ALLOWED_EXTENSIONS", "jpg,jpeg,png,gif")
    
    # 视频回放配置
    PLAYBACK_BASE_URL: str = os.getenv("PLAYBACK_BASE_URL", "http://localhost:8000")


# 创建全局配置实例
settings = Settings() 