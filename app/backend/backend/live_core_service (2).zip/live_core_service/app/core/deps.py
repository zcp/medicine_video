"""
依赖注入模块
提供FastAPI依赖注入函数
"""

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict
from app.core.auth import JWTAuth
from app.database import get_db
import time


async def get_current_user(token: Dict = Depends(JWTAuth.get_current_user)) -> Dict:
    """获取当前认证用户"""
    return token


# 为了测试方便，提供一个独立的函数
async def get_current_user_for_test() -> Dict:
    """获取当前认证用户（测试用）"""
    return {
        "user_id": "test-user-id-12345",
        "sub": "test-user-id-12345",
        "email": "test@example.com",
        "exp": int(time.time()) + 3600
    }
